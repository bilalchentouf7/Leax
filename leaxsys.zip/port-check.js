#!/usr/bin/env node
// Outbound connectivity test for shared hosting (cPanel, etc.).
//
// Usage:
//   node test-port.js                              Test default targets (outbound HTTPS + Clever Cloud DB)
//   node test-port.js host:port [host:port ...]    Test specific endpoints, e.g. 1.2.3.4:27017
//   node test-port.js cluster0.abcde.mongodb.net  Resolve a MongoDB Atlas SRV hostname and test its shards
//
// Uses only Node built-ins, so it runs without installing dependencies.

"use strict";

const dns = require("dns");
const https = require("https");
const net = require("net");

const DEFAULT_TARGETS = [
  "api.ipify.org:443",
  "bbtstruwrnpa1xgds8ds-mongodb.services.clever-cloud.com:2134"
];

const TIMEOUT_MS = 8000;

function testTcp(host, port) {
  return new Promise((resolve) => {
    if (!host || !Number.isInteger(port)) {
      resolve({ target: `${host}:${port}`, status: "INVALID", detail: "expected host:port" });
      return;
    }
    const socket = new net.Socket();
    const done = (status, detail) => {
      socket.destroy();
      resolve({ target: `${host}:${port}`, status, detail });
    };
    socket.setTimeout(TIMEOUT_MS);
    socket.once("connect", () => done("OPEN", "server can reach this endpoint"));
    socket.once("timeout", () => done("BLOCKED", "connection timed out (likely a hosting firewall)"));
    socket.once("error", (error) => done("BLOCKED", describeError(error)));
    socket.connect(port, host);
  });
}

function resolveSrvTargets(hostname) {
  return new Promise((resolve) => {
    dns.resolveSrv(`_mongodb._tcp.${hostname}`, (error, addresses) => {
      if (error || !Array.isArray(addresses) || addresses.length === 0) {
        resolve(null);
        return;
      }
      resolve(addresses.map((entry) => `${entry.name}:${entry.port || 27017}`));
    });
  });
}

const ERROR_HINTS = {
  ENOTFOUND: "DNS lookup failed for this hostname",
  EAI_AGAIN: "DNS lookup timed out",
  ECONNREFUSED: "connection refused (port not open on the destination)",
  ETIMEDOUT: "timed out (likely a hosting firewall dropping the connection)"
};

function describeError(error) {
  return ERROR_HINTS[error.code] || error.code || error.message;
}

const IP_ECHO_SERVICES = ["api.ipify.org", "ipv4.icanhazip.com", "ifconfig.me"];

function fetchPublicIp() {
  return new Promise((resolve) => {
    let index = 0;
    const tryNext = () => {
      if (index >= IP_ECHO_SERVICES.length) {
        resolve("unknown");
        return;
      }
      const host = IP_ECHO_SERVICES[index++];
      const request = https.get(`https://${host}`, { timeout: TIMEOUT_MS }, (response) => {
        let body = "";
        response.on("data", (chunk) => (body += chunk));
        response.on("end", () => {
          const ip = body.trim();
          if (/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) resolve(ip);
          else tryNext();
        });
      });
      request.on("timeout", () => {
        request.destroy();
        tryNext();
      });
      request.on("error", tryNext);
    };
    tryNext();
  });
}

async function expandTargets(rawTargets) {
  const expanded = [];
  for (const raw of rawTargets) {
    if (raw.includes(":")) {
      expanded.push(raw);
      continue;
    }
    const srvTargets = await resolveSrvTargets(raw);
    if (srvTargets) {
      expanded.push(...srvTargets);
    } else {
      expanded.push(`${raw}:27017`);
    }
  }
  return expanded;
}

async function main() {
  const rawTargets = process.argv.slice(2);
  const targets = await expandTargets(rawTargets.length > 0 ? rawTargets : DEFAULT_TARGETS);

  const publicIp = await fetchPublicIp();
  console.log(`Outbound public IP: ${publicIp}  <- add this to Atlas "Network Access"`);
  console.log("");

  let allOpen = true;
  for (const target of targets) {
    const [host, port] = target.split(":");
    const result = await testTcp(host, Number(port));
    if (result.status !== "OPEN") allOpen = false;
    console.log(`${result.status.padEnd(8)} ${result.target}${result.detail ? `  (${result.detail})` : ""}`);
  }

  console.log("");
  console.log(
    allOpen
      ? "All endpoints reachable. MongoDB over this port should work on this server."
      : "At least one endpoint is BLOCKED: the hosting firewall is filtering that host/port."
  );
  process.exitCode = allOpen ? 0 : 1;
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
