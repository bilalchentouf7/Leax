document.addEventListener("submit", (event) => {
  const submitter = event.submitter;
  const message = submitter && submitter.dataset.confirm;
  if (message && !window.confirm(message)) event.preventDefault();
});

document.addEventListener("change", (event) => {
  const input = event.target.closest(".banner-upload-input");
  if (!input || !input.files?.length) return;
  const form = input.closest("form[data-banner-upload]");
  if (form) form.submit();
});

document.addEventListener("keydown", (event) => {
  if ((event.key === "Enter" || event.key === " ") && event.target.matches(".banner-upload-label, .banner-upload-drop")) {
    const input = event.target.querySelector(".banner-upload-input");
    if (input) {
      event.preventDefault();
      input.click();
    }
  }
});

document.addEventListener("click", async (event) => {
  const button = event.target.closest(".media-copy[data-copy]");
  if (!button) return;
  try {
    await navigator.clipboard.writeText(button.dataset.copy);
    const previous = button.textContent;
    button.textContent = button.dataset.copied || "Copied";
    window.setTimeout(() => { button.textContent = previous; }, 1600);
  } catch {
    window.prompt("Copy asset path:", button.dataset.copy);
  }
});

const serviceRows = document.querySelector("#service-order-list[data-reorder-enabled='true']");
if (serviceRows) {
  let draggedRow = null;

  serviceRows.addEventListener("dragstart", (event) => {
    draggedRow = event.target.closest("tr[data-service-id]");
    if (!draggedRow) return;
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData("text/plain", draggedRow.dataset.serviceId);
    draggedRow.classList.add("is-dragging");
  });

  serviceRows.addEventListener("dragover", (event) => {
    event.preventDefault();
    const target = event.target.closest("tr[data-service-id]");
    if (!draggedRow || !target || draggedRow === target) return;
    const bounds = target.getBoundingClientRect();
    serviceRows.insertBefore(draggedRow, event.clientY > bounds.top + bounds.height / 2 ? target.nextSibling : target);
  });

  serviceRows.addEventListener("dragend", async () => {
    if (!draggedRow) return;
    draggedRow.classList.remove("is-dragging");
    draggedRow = null;
    const token = document.querySelector("input[name='_csrf']")?.value;
    const ids = [...serviceRows.querySelectorAll("tr[data-service-id]")].map((row) => row.dataset.serviceId);
    try {
      const response = await fetch(serviceRows.dataset.reorderUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRF-Token": token || "" },
        body: JSON.stringify({ ids, offset: Number(serviceRows.dataset.offset || 0) })
      });
      if (!response.ok) {
        const result = await response.json().catch(() => ({}));
        throw new Error(result.error || "The service order could not be saved.");
      }
      window.location.reload();
    } catch (error) {
      window.alert(error.message);
      window.location.reload();
    }
  });
}

document.querySelectorAll("[data-order-chat]").forEach((chat) => {
  const messages = chat.querySelector(".order-chat-messages");
  const error = chat.querySelector(".chat-error");
  chat.seenMessageIds = new Set();

  const showError = (message) => {
    error.textContent = message;
    error.hidden = false;
  };

  const addMessage = (message) => {
    if (chat.seenMessageIds.has(message.id)) return;
    chat.seenMessageIds.add(message.id);
    messages.querySelector(".chat-empty")?.remove();
    const item = document.createElement("article");
    item.className = message.sender.id === document.body.dataset.userId ? "chat-message is-mine" : "chat-message";
    const heading = document.createElement("div");
    heading.className = "chat-message-heading";
    const sender = document.createElement("strong");
    sender.textContent = message.sender.name;
    const time = document.createElement("time");
    time.dateTime = new Date(message.createdAt).toISOString();
    time.textContent = new Date(message.createdAt).toLocaleString();
    const body = document.createElement("p");
    body.textContent = message.body;
    heading.append(sender, time);
    item.append(heading, body);
    messages.append(item);
    messages.scrollTop = messages.scrollHeight;
  };

  const refresh = async () => {
    try {
      const response = await fetch(chat.dataset.messagesUrl, { headers: { Accept: "application/json" } });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Could not load messages.");
      result.messages.forEach(addMessage);
      error.hidden = true;
    } catch {
      showError(chat.dataset.loadError || "Messages could not be loaded. Please try again.");
    }
  };

  const shell = chat.closest("details");
  shell?.addEventListener("toggle", () => {
    if (shell.open && !chat.pollTimer) {
      refresh();
      chat.pollTimer = window.setInterval(refresh, 3000);
    } else if (!shell.open && chat.pollTimer) {
      window.clearInterval(chat.pollTimer);
      chat.pollTimer = null;
    }
  });

  chat.querySelector("[data-order-chat-form]")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const input = form.elements.body;
    const button = form.querySelector("button[type='submit'], button:not([type])");
    const token = form.elements._csrf.value;
    button.disabled = true;
    error.hidden = true;
    try {
      const response = await fetch(chat.dataset.messagesUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRF-Token": token, Accept: "application/json" },
        body: JSON.stringify({ body: input.value })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Message could not be sent.");
      addMessage(result.message);
      input.value = "";
    } catch (requestError) {
      showError(requestError.message);
    } finally {
      button.disabled = false;
      input.focus();
    }
  });
});
