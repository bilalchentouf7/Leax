const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("node:path");
const fs = require("node:fs/promises");
const sharp = require("sharp");
const { MediaUploadError, saveOwnerMedia, listOwnerMedia } = require("../src/utils/media-upload");

test("owner media upload re-encodes supported banner images to bounded WebP assets", async () => {
  const input = await sharp({
    create: { width: 2400, height: 1200, channels: 3, background: "#345678" }
  }).png().toBuffer();
  let asset;
  try {
    asset = await saveOwnerMedia({ buffer: input }, "banner");
    const filepath = path.join(__dirname, "..", "public", "assets", "uploads", asset.filename);
    const metadata = await sharp(await fs.readFile(filepath)).metadata();
    assert.match(asset.path, /^\/assets\/uploads\/banner-[a-f0-9-]{36}\.webp$/i);
    assert.equal(metadata.format, "webp");
    assert.ok(metadata.width <= 2000);
    assert.ok(metadata.height <= 1000);
    assert.ok((await listOwnerMedia()).some((item) => item.name === asset.filename));
  } finally {
    if (asset) {
      await fs.unlink(path.join(__dirname, "..", "public", "assets", "uploads", asset.filename));
    }
  }
});

test("media upload rejects SVG and missing files", async () => {
  const svg = Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10"></svg>');
  await assert.rejects(
    saveOwnerMedia({ buffer: svg }, "icon"),
    (error) => error instanceof MediaUploadError && error.translationKey === "uploadInvalidImage"
  );
  await assert.rejects(
    saveOwnerMedia(undefined, "banner"),
    (error) => error instanceof MediaUploadError && error.translationKey === "uploadChooseFile"
  );
});
