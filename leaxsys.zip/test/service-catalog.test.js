const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { localizeService, localizeCategory } = require("../src/utils/service-catalog");
const arabic = require("../src/locales/ar");
const english = require("../src/locales/en");

test("included service slugs and categories have Arabic catalog translations", () => {
  const slugs = [
    "website-installation-setup",
    "control-panel-installation",
    "ssl-certificate-installation",
    "website-security-hardening",
    "cloudflare-protection-setup",
    "vulnerability-check",
    "website-management-maintenance",
    "server-management-monitoring",
    "website-backup-updates"
  ];
  for (const slug of slugs) {
    const service = localizeService({
      slug, name: "English name", shortDescription: "English copy", description: "English description",
      features: [], requirements: [], faqs: [], deliveryTime: "One day"
    }, "ar");
    assert.notEqual(service.name, "English name", `${slug} should be localized`);
    assert.ok(service.description.length > 0);
  }
  assert.equal(localizeCategory({ slug: "web-security", name: "Web Security" }, "ar").name, "خدمات حماية الويب");
});

test("owner-supplied Arabic service fields override catalog defaults", () => {
  const service = localizeService({
    slug: "custom-service",
    name: "English name",
    nameAr: "اسم مخصص",
    shortDescription: "English short description",
    shortDescriptionAr: "وصف مختصر",
    description: "English description",
    descriptionAr: "وصف كامل",
    features: [],
    featuresAr: "ميزة أولى\nميزة ثانية",
    requirements: [],
    requirementsAr: "شرط أول",
    faqs: [],
    faqsAr: "سؤال؟ | جواب",
    deliveryTime: "One day",
    deliveryTimeAr: "يوم واحد"
  }, "ar");
  assert.equal(service.name, "اسم مخصص");
  assert.deepEqual(service.features, ["ميزة أولى", "ميزة ثانية"]);
  assert.deepEqual(service.faqs, [{ question: "سؤال؟", answer: "جواب" }]);
  assert.equal(service.deliveryTime, "يوم واحد");
});

test("client dashboard and owner media labels are available in both locales", () => {
  const required = [
    "clientWelcome", "clientAccountType", "clientRequestCount", "clientQuotes",
    "ownerClientAccounts", "ownerTotalClients", "ownerActiveClients", "ownerClientsWithRequests",
    "mediaTitle", "mediaUploadTitle", "mediaUploadHelp", "mediaImage",
    "uploadInvalidImage", "uploadAnimatedImage"
  ];
  for (const key of required) {
    assert.ok(english[key], `English locale missing ${key}`);
    assert.ok(arabic[key], `Arabic locale missing ${key}`);
  }
});

test("every statically referenced view translation exists in both locales", () => {
  const missing = { en: [], ar: [] };
  function inspect(directory) {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const filename = path.join(directory, entry.name);
      if (entry.isDirectory()) {
        inspect(filename);
      } else if (filename.endsWith(".ejs")) {
        const source = fs.readFileSync(filename, "utf8");
        for (const [, key] of source.matchAll(/\bt\(['"]([^'"]+)['"]\)/g)) {
          if (!english[key]) missing.en.push(`${filename}: ${key}`);
          if (!arabic[key]) missing.ar.push(`${filename}: ${key}`);
        }
      }
    }
  }
  inspect(path.join(__dirname, "..", "src", "views"));
  assert.deepEqual(missing, { en: [], ar: [] });
});
