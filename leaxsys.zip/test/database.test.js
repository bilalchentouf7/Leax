const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const {
  database,
  connectDatabase,
  closeDatabase,
  initializeOwner,
  databaseInternals: { collections, matches, setDatabasePathForTests, createMongoAdapter }
} = require("../src/utils/database");

test("Lowdb persists application records, relations, filters, aggregates, and concurrent writes", async () => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "leaxsys-lowdb-"));
  const file = path.join(directory, "store.json");
  setDatabasePathForTests(file);

  try {
    assert.deepEqual(Object.keys(collections), [
      "user", "category", "service", "order", "orderMessage", "payment",
      "activityLog", "siteSetting", "webSession"
    ]);
    await assert.rejects(database.user.count(), /Database is not initialized/);
    await connectDatabase();

    process.env.OWNER_EMAIL = "owner@example.test";
    process.env.OWNER_PASSWORD = "a-test-owner-password-that-is-long-enough";
    process.env.OWNER_NAME = "Test Owner";
    assert.equal(await initializeOwner(), true);
    assert.equal(await initializeOwner(), true);
    assert.equal((await database.user.findUnique({ where: { email: process.env.OWNER_EMAIL } })).role, "OWNER");

    const user = await database.user.create({
      data: { name: "Test Client", email: "client@example.com", passwordHash: "hash" }
    });

    const category = await database.category.create({ data: { name: "Infrastructure", slug: "infrastructure" } });
    const service = await database.service.create({
      data: {
        name: "Reliability Review",
        slug: "reliability-review",
        categoryId: category.id,
        pricingModel: "QUOTE",
        icon: "SHIELD",
        shortDescription: "A focused service for testing public catalog pages."
      }
    });
    const order = await database.order.create({
      data: { userId: user.id, serviceId: service.id, amount: 125, currency: "USD" }
    });

    const usersWithOrderCounts = await database.user.findMany({
      select: { id: true, _count: { select: { orders: true } } }
    });
    assert.equal(usersWithOrderCounts.find(({ id }) => id === user.id)._count.orders, 1);

    const nestedOrder = await database.order.findUnique({
      where: { id: order.id },
      include: { service: { include: { category: true } }, user: true }
    });
    assert.equal(nestedOrder.service.category.id, category.id);
    assert.equal(nestedOrder.user.email, "client@example.com");
    assert.equal(await database.order.count({
      where: {
        userId: user.id,
        service: { pricingModel: { in: ["QUOTE", "MONTHLY"] } }
      }
    }), 1);
    assert.equal(await database.user.count({ where: { orders: { some: { id: order.id } } } }), 1);

    const grouped = await database.order.groupBy({
      by: ["currency"],
      where: { paymentStatus: "UNPAID" },
      _sum: { amount: true }
    });
    assert.deepEqual(grouped.map(({ currency, _sum }) => [currency, _sum.amount]), [["USD", 125]]);
    const popular = await database.order.groupBy({
      by: ["serviceId"],
      _count: { serviceId: true },
      orderBy: { _count: { serviceId: "desc" } },
      take: 1
    });
    assert.deepEqual(popular.map(({ serviceId, _count }) => [serviceId, _count.serviceId]), [[service.id, 1]]);

    await database.payment.upsert({
      where: { orderId: order.id },
      create: { orderId: order.id, provider: "PAYPAL", amount: 125, currency: "USD", status: "PENDING" },
      update: { status: "PAID" }
    });
    await database.payment.upsert({
      where: { orderId: order.id },
      create: { orderId: order.id, provider: "PAYPAL", amount: 125, currency: "USD", status: "PENDING" },
      update: { status: "PAID" }
    });
    assert.equal(await database.payment.count({ where: { orderId: order.id } }), 1);
    assert.equal((await database.payment.findUnique({ where: { orderId: order.id } })).status, "PAID");

    const now = new Date();
    assert.equal(await matches("order", { createdAt: now.toISOString() }, { createdAt: { gte: new Date(now.getTime() - 1000) } }), true);
    assert.equal((await database.category.findMany({
      include: { _count: { select: { services: true } } }
    }))[0]._count.services, 1);

    await assert.rejects(
      database.user.create({ data: { name: "Duplicate", email: "client@example.com", passwordHash: "hash" } }),
      (error) => error.code === "P2002"
    );

    await Promise.all(Array.from({ length: 5 }, (_, index) =>
      database.orderMessage.create({
        data: { orderId: order.id, senderId: user.id, body: `Message ${index}` }
      })
    ));
    assert.equal(await database.orderMessage.count({ where: { orderId: order.id } }), 5);

    await database.siteSetting.upsert({
      where: { key: "contactEmail" },
      create: { key: "contactEmail", value: "first@example.com" },
      update: { value: "second@example.com" }
    });
    await database.siteSetting.upsert({
      where: { key: "contactEmail" },
      create: { key: "contactEmail", value: "first@example.com" },
      update: { value: "second@example.com" }
    });
    assert.equal((await database.siteSetting.findUnique({ where: { key: "contactEmail" } })).value, "second@example.com");

    await closeDatabase();
    const saved = JSON.parse(await fs.readFile(file, "utf8"));
    assert.equal(saved.orders.length, 1);
    assert.equal(saved.orderMessages.length, 5);
    assert.equal(saved.payments.length, 1);
    await connectDatabase();
    assert.equal(await database.order.count(), 1);
    assert.ok((await database.order.findUnique({ where: { id: order.id } })).createdAt instanceof Date);

    process.env.SESSION_SECRET ||= "test-session-secret-with-more-than-32-characters";
    process.env.LOG_LEVEL ||= "silent";
    const { createApp } = require("../src/app");
    const server = await new Promise((resolve, reject) => {
      const listener = createApp().listen(0, "127.0.0.1", () => resolve(listener));
      listener.on("error", reject);
    });
    try {
      const servicesResponse = await fetch(`http://127.0.0.1:${server.address().port}/services`);
      assert.equal(servicesResponse.status, 200);
      assert.match(await servicesResponse.text(), /Reliability Review/);
      const licensesResponse = await fetch(`http://127.0.0.1:${server.address().port}/licenses`);
      assert.equal(licensesResponse.status, 200);
    } finally {
      await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    }
  } finally {
    await closeDatabase();
    await fs.rm(directory, { recursive: true, force: true });
  }
});

test("MongoDB adapter reads and writes one state document per logical collection", async () => {
  const documents = new Map();
  const collection = {
    find() {
      return {
        async toArray() {
          return [...documents.values()];
        }
      };
    },
    async bulkWrite(operations) {
      for (const operation of operations) {
        const replacement = operation.replaceOne.replacement;
        documents.set(replacement._id, structuredClone(replacement));
      }
    }
  };
  const adapter = createMongoAdapter(collection);
  const data = Object.fromEntries(Object.values(collections).map((name) => [name, []]));
  data.users.push({ id: "user-1", createdAt: new Date("2026-01-01T00:00:00.000Z") });

  assert.equal(await adapter.read(), null);
  await adapter.write(data);
  const restored = await adapter.read();
  assert.equal(documents.size, Object.values(collections).length);
  assert.deepEqual(restored, data);

  documents.delete("orders");
  await assert.rejects(adapter.read(), /state is incomplete/);
});
