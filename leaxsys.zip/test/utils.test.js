const test = require("node:test");
const assert = require("node:assert/strict");
const { toSlug } = require("../src/utils/slug");
const { localeMiddleware } = require("../src/middleware/locale");

test("slug helper normalizes accents and punctuation into URL-safe values", () => {
  assert.equal(toSlug("  SSL & Sécurité Setup! "), "ssl-securite-setup");
  assert.equal(toSlug("東京"), "");
});

test("locale middleware selects Arabic, sets a preference cookie, and exposes RTL translations", () => {
  const req = { query: { lang: "ar" }, headers: { cookie: "" } };
  const res = {
    locals: {},
    cookie(name, value) {
      this.languageCookie = [name, value];
    }
  };
  let continued = false;
  localeMiddleware(req, res, () => { continued = true; });
  assert.equal(continued, true);
  assert.equal(req.locale, "ar");
  assert.equal(res.locals.dir, "rtl");
  assert.equal(req.t("signIn"), "تسجيل الدخول");
  assert.deepEqual(res.languageCookie, ["leaxsys_lang", "ar"]);
});

test("locale middleware reuses only supported language cookies", () => {
  const req = { query: {}, headers: { cookie: "leaxsys_lang=ar" } };
  const res = { locals: {}, cookie() { assert.fail("Unrequested locale should not rewrite cookie"); } };
  localeMiddleware(req, res, () => {});
  assert.equal(req.locale, "ar");
  assert.equal(res.locals.dir, "rtl");
});
