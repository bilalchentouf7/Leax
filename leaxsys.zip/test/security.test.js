const test = require("node:test");
const assert = require("node:assert/strict");
const { attachCsrfToken, csrfProtection } = require("../src/middleware/csrf");
const { requireOwner } = require("../src/middleware/auth");

function responseStub() {
  return {
    locals: {},
    status(code) {
      this.statusCode = code;
      return this;
    },
    send(body) {
      this.body = body;
      return this;
    },
    render(view, locals) {
      this.view = view;
      this.locals = locals;
      return this;
    },
    redirect(path) {
      this.redirectPath = path;
      return this;
    }
  };
}

test("CSRF middleware accepts the session token and rejects missing or incorrect tokens", () => {
  let sessionSaved = false;
  const req = {
    session: { save(callback) { sessionSaved = true; callback(null); } },
    method: "GET", body: {}, get: () => null
  };
  const res = responseStub();
  attachCsrfToken(req, res, () => {});
  assert.equal(sessionSaved, true);
  assert.match(req.session.csrfToken, /^[a-f0-9]{64}$/);

  req.method = "POST";
  req.body._csrf = req.session.csrfToken;
  let allowed = false;
  csrfProtection(req, res, () => { allowed = true; });
  assert.equal(allowed, true);

  req.body._csrf = "incorrect";
  csrfProtection(req, res, () => assert.fail("Invalid CSRF token was accepted"));
  assert.equal(res.statusCode, 403);

  req.body = {};
  csrfProtection(req, res, () => assert.fail("Missing CSRF token was accepted"));
  assert.equal(res.statusCode, 403);
});

test("owner guard redirects anonymous users, rejects clients, and permits owners", () => {
  const anonymousResponse = responseStub();
  requireOwner({ user: null, originalUrl: "/owner/settings" }, anonymousResponse, () => {
    assert.fail("Anonymous request passed owner guard");
  });
  assert.equal(anonymousResponse.redirectPath, "/login?next=%2Fowner%2Fsettings");

  const clientResponse = responseStub();
  requireOwner({ user: { role: "USER" }, t: () => "Access denied" }, clientResponse, () => {
    assert.fail("Client request passed owner guard");
  });
  assert.equal(clientResponse.statusCode, 403);
  assert.equal(clientResponse.view, "errors/error");

  let ownerAllowed = false;
  requireOwner({ user: { role: "OWNER" } }, responseStub(), () => { ownerAllowed = true; });
  assert.equal(ownerAllowed, true);
});
