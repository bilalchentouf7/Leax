const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { database, connectDatabase, closeDatabase, databaseInternals: { setDatabasePathForTests } } = require("../src/utils/database");
const { initializeServiceCatalog } = require("../src/utils/service-seed");

test("startup seeds the three web service store categories idempotently", async () => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "leaxsys-services-"));
  setDatabasePathForTests(path.join(directory, "store.json"));

  try {
    await connectDatabase();
    const firstSeed = await initializeServiceCatalog();
    assert.equal(firstSeed.length, 9);
    assert.deepEqual(firstSeed.map(({ name, price }) => [name, price]), [
      ["Website Installation & Setup", 15],
      ["Control Panel Installation", 20],
      ["SSL Certificate Installation", 10],
      ["Website Security Hardening", 25],
      ["Cloudflare Protection Setup", 20],
      ["Website Vulnerability Check", 30],
      ["Website Management & Maintenance", 25],
      ["Server Management & Monitoring", 35],
      ["Website Backup & Updates", 15]
    ]);

    for (const [slug, expectedName] of [
      ["web-installation", "Web Installation Services"],
      ["web-security", "Web Security Services"],
      ["web-management", "Web Management Services"]
    ]) {
      const category = await database.category.findUnique({ where: { slug } });
      assert.equal(category.name, expectedName);
      assert.equal(await database.service.count({ where: { categoryId: category.id, currency: "USD", deliveryTime: "1 day" } }), 3);
    }
    assert.deepEqual(await initializeServiceCatalog(), []);

    process.env.SESSION_SECRET ||= "test-session-secret-with-more-than-32-characters";
    process.env.LOG_LEVEL ||= "silent";
    const { createApp } = require("../src/app");
    const server = await new Promise((resolve, reject) => {
      const listener = createApp().listen(0, "127.0.0.1", () => resolve(listener));
      listener.on("error", reject);
    });
    try {
      const response = await fetch(`http://127.0.0.1:${server.address().port}/services`);
      const html = (await response.text()).replaceAll(String.fromCharCode(38) + "amp;", String.fromCharCode(38));
      assert.equal(response.status, 200);
      for (const name of ["Website Installation & Setup", "Website Security Hardening", "Website Management & Maintenance"]) {
        assert.ok(html.includes(name), `${name} should be visible in the public catalog`);
      }
    } finally {
      await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    }

    const installService = await database.service.findUnique({ where: { slug: "website-installation-setup" } });
    await database.service.update({
      where: { id: installService.id },
      data: { price: 18 }
    });
    await initializeServiceCatalog();
    assert.equal((await database.service.findUnique({ where: { slug: "website-installation-setup" } })).price, 18);
  } finally {
    await closeDatabase();
    await fs.rm(directory, { recursive: true, force: true });
  }
});
