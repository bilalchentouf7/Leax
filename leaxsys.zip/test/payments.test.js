const test = require("node:test");
const assert = require("node:assert/strict");
const { amountMatches } = require("../src/utils/paypal");
const { isTrustedApprovalUrl, canStartPayment } = require("../src/routes/payments");

test("PayPal amount verification requires an exact amount and currency", () => {
  assert.equal(amountMatches({ value: "45.00", currency_code: "USD" }, 45, "USD"), true);
  assert.equal(amountMatches({ value: "44.99", currency_code: "USD" }, 45, "USD"), false);
  assert.equal(amountMatches({ value: "45.00", currency_code: "EUR" }, 45, "USD"), false);
  assert.equal(amountMatches({ value: "45.000", currency_code: "USD" }, 45, "USD"), false);
  assert.equal(amountMatches(null, 45, "USD"), false);
});

test("PayPal redirects allow only official HTTPS approval hosts", () => {
  assert.equal(isTrustedApprovalUrl("https://www.paypal.com/checkoutnow?token=abc"), true);
  assert.equal(isTrustedApprovalUrl("https://www.sandbox.paypal.com/checkoutnow?token=abc"), true);
  assert.equal(isTrustedApprovalUrl("http://www.paypal.com/checkoutnow"), false);
  assert.equal(isTrustedApprovalUrl("https://paypal.example.invalid/checkoutnow"), false);
  assert.equal(isTrustedApprovalUrl("javascript:alert(1)"), false);
});

test("payment is only available after an owner offer and explicit client acceptance", () => {
  const service = { pricingModel: "FIXED" };
  const acceptedOrder = {
    status: "PROCESSING",
    ownerAcceptedAt: new Date(),
    clientAcceptedAt: new Date(),
    paymentStatus: "UNPAID",
    amount: 45
  };

  assert.equal(canStartPayment(acceptedOrder, service), true);
  assert.equal(canStartPayment({ ...acceptedOrder, ownerAcceptedAt: null }, service), false);
  assert.equal(canStartPayment({ ...acceptedOrder, status: "PENDING" }, service), false);
  assert.equal(canStartPayment({ ...acceptedOrder, clientAcceptedAt: null }, service), false);
  assert.equal(canStartPayment({ ...acceptedOrder, amount: 0 }, service), false);
  assert.equal(canStartPayment({ ...acceptedOrder, paymentStatus: "PAID" }, service), false);
  assert.equal(canStartPayment(acceptedOrder, { pricingModel: "MONTHLY" }), false);
  assert.equal(canStartPayment(acceptedOrder, { pricingModel: "QUOTE" }), true);
});
