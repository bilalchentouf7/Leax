const path = require("node:path");
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const compression = require("compression");
const pinoHttp = require("pino-http");
const { rateLimit } = require("express-rate-limit");
const { logger } = require("./utils/logger");
const { database } = require("./utils/database");
const { LowdbSessionStore } = require("./utils/session-store");
const passport = require("passport");
const { configureOAuth } = require("./utils/oauth");
const { csrfProtection, attachCsrfToken } = require("./middleware/csrf");
const { loadUser } = require("./middleware/auth");
const { localeMiddleware } = require("./middleware/locale");
const { maintenanceMiddleware } = require("./middleware/maintenance");
const { publicRouter } = require("./routes/public");
const { authRouter, authLimiter } = require("./routes/auth");
const { ownerRouter } = require("./routes/owner");
const { dashboardRouter } = require("./routes/dashboard");
const { paymentsRouter } = require("./routes/payments");
const { paypalEnabled } = require("./utils/paypal");
const { requireOwner } = require("./middleware/auth");
const { parseOwnerMediaUpload } = require("./utils/media-upload");
  //Ejs Startup
function createApp() {
  const app = express();
  const production = process.env.NODE_ENV === "production";
  const providers = configureOAuth(passport);

  if (production) app.set("trust proxy", 1);


  app.set("view engine", "ejs");
  app.set("views", path.join(__dirname, "views"));
  app.disable("x-powered-by");
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        imgSrc: ["'self'", "data:", "https://images.dmca.com"],
        scriptSrc: ["'self'", "https://images.dmca.com"],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        upgradeInsecureRequests: production ? [] : null
      }
    }
  }));
  app.use(compression());
  app.use(pinoHttp({ logger }));
  app.use(express.static(path.join(__dirname, "..", "public"), { maxAge: production ? "1d" : 0 }));
  app.use(session({
    name: "leaxsys.sid",
    store: new LowdbSessionStore(),
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: production,
      sameSite: "lax",
      maxAge: 1000 * 60 * 60 * 8
    }
  }));
  app.use(passport.initialize());
  app.use(localeMiddleware);
  app.post("/login", authLimiter);
  app.post("/register", authLimiter);
  app.use((req, res, next) => {
    res.locals.path = req.path;
    res.locals.bodyClass = "";
    res.locals.error = null;
    res.locals.nextPath = "";
    res.locals.subtitle = "";
    res.locals.user = null;
    res.locals.paypalEnabled = paypalEnabled;
    res.locals.oauthProviders = Object.entries(providers)
      .filter(([, provider]) => provider.enabled)
      .map(([name]) => name);
    res.locals.flash = req.session.flash || null;
    delete req.session.flash;
    next();
  });
  app.use(loadUser);
  app.use(async (req, res, next) => {
    try {
      const settings = Object.fromEntries(
        (await database.siteSetting.findMany()).map(({ key, value }) => [key, value])
      );
      res.locals.publicContacts = {
        contactEmail: settings.contactEmail || "BilalChentouf102@Gmail.com",
        whatsappNumber: settings.whatsappNumber || "",
        discordUrl: settings.discordUrl || ""
      };
      next();
    } catch (error) {
      next(error);
    }
  });
  app.use(attachCsrfToken);
  app.use(maintenanceMiddleware);
  app.use(express.urlencoded({ extended: false, limit: "20kb" }));
  app.use(express.json({ limit: "20kb" }));
  app.post("/owner/media/upload", requireOwner, parseOwnerMediaUpload);
  app.post("/owner/services/:id/banner", requireOwner, parseOwnerMediaUpload);
  app.use(csrfProtection);
  app.use("/", publicRouter);
  app.use("/", authRouter);
  app.use("/dashboard", dashboardRouter);
  app.use("/payments", paymentsRouter);
  app.use("/owner", ownerRouter);

  app.use((req, res) => res.status(404).render("errors/error", {
    status: 404,
    title: req.t("notFoundTitle"),
    message: req.t("notFoundMessage")
  }));
  app.use((error, req, res, next) => {
    if (res.headersSent) return next(error);
    req.log?.error({ err: error }, "Request failed");
    if (error.code === "P2002") {
      if (req.session) req.session.flash = { type: "error", message: req.t?.("duplicateValue") || "That value is already in use." };
      const referer = req.get("referer") || "";
      const returnPath = referer.startsWith("/") && !referer.startsWith("//") ? referer : "/";
      return res.redirect(returnPath);
    }
    if (error.code === "P2025") {
      return res.status(404).render("errors/error", {
        status: 404,
        title: req.t?.("notFoundTitle") || "Resource not found",
        message: req.t?.("notFoundMessage") || "The requested resource is unavailable."
      });
    }
    res.status(error.status || 500).render("errors/error", {
      status: error.status || 500,
      title: req.t?.("serverErrorTitle") || "System error",
      message: production ? (req.t?.("serverErrorMessage") || "Please try again later.") : error.message
    });
  });

  app.locals.database = database;
  return app;
}

module.exports = { createApp };
