const { z } = require("zod");

const environment = process.env.PAYPAL_ENVIRONMENT || "sandbox";
if (!["sandbox", "live"].includes(environment)) {
  throw new Error("PAYPAL_ENVIRONMENT must be sandbox or live.");
}

const clientId = process.env.PAYPAL_CLIENT_ID || "";
const clientSecret = process.env.PAYPAL_CLIENT_SECRET || "";
if (Boolean(clientId) !== Boolean(clientSecret)) {
  throw new Error("PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET must both be configured.");
}

const paypalEnabled = Boolean(clientId);
const apiBase = environment === "live"
  ? "https://api-m.paypal.com"
  : "https://api-m.sandbox.paypal.com";

async function getAccessToken() {
  const response = await fetch(`${apiBase}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString("base64")}`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "grant_type=client_credentials",
    signal: AbortSignal.timeout(10000)
  });
  const body = await response.json();
  if (!response.ok || !body.access_token) {
    throw new Error(`PayPal authentication failed with status ${response.status}.`);
  }
  return body.access_token;
}

async function paypalApi(path, { method = "GET", body, requestId } = {}) {
  if (!paypalEnabled) throw new Error("PayPal is not configured.");
  const token = await getAccessToken();
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: "application/json",
    "Content-Type": "application/json"
  };
  if (requestId) headers["PayPal-Request-Id"] = requestId;
  const response = await fetch(`${apiBase}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(15000)
  });
  const responseBody = await response.json().catch(() => null);
  if (!response.ok) throw new Error(`PayPal request failed with status ${response.status}.`);
  return responseBody;
}

function amountMatches(value, expectedAmount, expectedCurrency) {
  const parsed = z.object({
    value: z.string().regex(/^\d+(?:\.\d{1,2})?$/),
    currency_code: z.string().length(3)
  }).safeParse(value);
  return parsed.success
    && parsed.data.currency_code.toUpperCase() === expectedCurrency.toUpperCase()
    && Math.round(Number(parsed.data.value) * 100) === Math.round(Number(expectedAmount) * 100);
}

module.exports = { paypalEnabled, paypalApi, amountMatches };
