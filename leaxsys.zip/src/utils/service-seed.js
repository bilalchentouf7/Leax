const { database } = require("./database");

const categories = [
  {
    name: "Web Installation Services",
    slug: "web-installation",
    description: "Professional installation and setup for websites, control panels, and SSL.",
    icon: "rocket",
    displayOrder: 1,
    active: true,
    services: [
      {
        name: "Website Installation & Setup",
        slug: "website-installation-setup",
        shortDescription: "Complete installation of your website, domain DNS connection, and hosting configuration.",
        description: "I will install and configure your website on your hosting, connect your domain DNS, and verify everything works end to end.",
        price: 15,
        features: [
          "Website installation on your hosting",
          "Domain DNS connection",
          "Hosting configuration and verification"
        ],
        displayOrder: 1,
        featured: true
      },
      {
        name: "Control Panel Installation",
        slug: "control-panel-installation",
        shortDescription: "Installation and configuration of CyberPanel, cPanel, or another control panel on your server.",
        description: "I will install and configure CyberPanel, cPanel, or another control panel on your Linux server, with domains, SSL, and basic tuning included.",
        price: 20,
        features: [
          "Control panel installation (CyberPanel, cPanel, and more)",
          "Domain and SSL configuration",
          "Basic performance tuning"
        ],
        displayOrder: 2,
        featured: false
      },
      {
        name: "SSL Certificate Installation",
        slug: "ssl-certificate-installation",
        shortDescription: "Installation of an auto-renewing SSL certificate and HTTPS verification.",
        description: "I will install an auto-renewing SSL certificate on your website, verify the HTTPS redirect, and fix mixed-content warnings.",
        price: 10,
        features: [
          "Auto-renewing SSL certificate installation",
          "HTTPS redirect verification",
          "Mixed-content fixes"
        ],
        displayOrder: 3,
        featured: false
      }
    ]
  },
  {
    name: "Web Security Services",
    slug: "web-security",
    description: "Hardening, protection, and vulnerability checks for websites and servers.",
    icon: "shield",
    displayOrder: 2,
    active: true,
    services: [
      {
        name: "Website Security Hardening",
        slug: "website-security-hardening",
        shortDescription: "Server and website hardening with firewalls, access control, and documented settings.",
        description: "I will harden your website and server: firewall configuration, access control, updates, and security settings, with every change documented.",
        price: 25,
        features: [
          "Firewall and access-control configuration",
          "Security updates and settings review",
          "Documented hardening report"
        ],
        displayOrder: 1,
        featured: true
      },
      {
        name: "Cloudflare Protection Setup",
        slug: "cloudflare-protection-setup",
        shortDescription: "Cloudflare connection, SSL, WAF, and email DNS fixes for full protection.",
        description: "I will connect your website to Cloudflare and configure SSL, the WAF, DNS records, and email deliverability fixes.",
        price: 20,
        features: [
          "Cloudflare connection and DNS setup",
          "SSL and WAF configuration",
          "Email DNS record fixes"
        ],
        displayOrder: 2,
        featured: false
      },
      {
        name: "Website Vulnerability Check",
        slug: "vulnerability-check",
        shortDescription: "An authorized vulnerability review of your website with risk-ranked findings and fixes.",
        description: "An authorized, scoped security review of your website or application. I validate every finding and deliver risk-ranked recommendations you can act on.",
        price: 30,
        features: [
          "Scope and authorization confirmed first",
          "Non-destructive, agreed checks",
          "Risk-ranked findings and fix guidance"
        ],
        displayOrder: 3,
        featured: false
      }
    ]
  },
  {
    name: "Web Management Services",
    slug: "web-management",
    description: "Ongoing management, monitoring, backups, and updates for websites and servers.",
    icon: "server",
    displayOrder: 3,
    active: true,
    services: [
      {
        name: "Website Management & Maintenance",
        slug: "website-management-maintenance",
        shortDescription: "Ongoing care for your website: updates, fixes, and content changes handled for you.",
        description: "I will take care of your website on an ongoing basis: core and plugin updates, small fixes, and content changes, with a monthly report.",
        price: 25,
        features: [
          "Core and plugin updates",
          "Small fixes and content changes",
          "Monthly care report"
        ],
        displayOrder: 1,
        featured: true
      },
      {
        name: "Server Management & Monitoring",
        slug: "server-management-monitoring",
        shortDescription: "Proactive server management with monitoring, alerts, and incident response.",
        description: "I will manage your server proactively: uptime monitoring, resource alerts, security patching, and incident response when something needs attention.",
        price: 35,
        features: [
          "Uptime and resource monitoring",
          "Security patching",
          "Incident response and escalation"
        ],
        displayOrder: 2,
        featured: false
      },
      {
        name: "Website Backup & Updates",
        slug: "website-backup-updates",
        shortDescription: "Scheduled backups plus regular updates so your website stays safe and current.",
        description: "I will set up scheduled backups for your website files and database, keep everything updated, and verify backups restore correctly.",
        price: 15,
        features: [
          "Scheduled file and database backups",
          "Regular update checks",
          "Restore verification"
        ],
        displayOrder: 3,
        featured: false
      }
    ]
  }
].map((category) => ({
  ...category,
  services: category.services.map((service) => ({
    ...service,
    image: `/assets/banners/${service.slug}.svg`,
    pricingModel: "FIXED",
    currency: "USD",
    icon: category.icon,
    deliveryTime: "1 day",
    requirements: [
      "Access to your hosting, server, or domain",
      "Confirmation that you own the assets"
    ],
    faqs: [],
    active: true
  }))
}));

async function initializeServiceCatalog() {
  const createdServices = [];
  for (const category of categories) {
    let existingCategory = await database.category.findUnique({ where: { slug: category.slug } });
    if (!existingCategory) {
      const { services, ...categoryData } = category;
      existingCategory = await database.category.create({ data: categoryData });
    }

    for (const service of category.services) {
      const existingService = await database.service.findUnique({ where: { slug: service.slug } });
      if (existingService) {
        if (!existingService.image) {
          await database.service.update({
            where: { id: existingService.id },
            data: { image: service.image }
          });
        }
        continue;
      }
      createdServices.push(await database.service.create({
        data: { ...service, categoryId: existingCategory.id }
      }));
    }
  }
  return createdServices;
}

module.exports = { initializeServiceCatalog };
