const session = require("express-session");
const { database } = require("./database");

const DEFAULT_SESSION_AGE_MS = 1000 * 60 * 60 * 8;

class LowdbSessionStore extends session.Store {
  get(sid, callback) {
    database.webSession.findUnique({ where: { sid } }).then(async (record) => {
      if (!record) return callback(null, null);
      if (record.expiresAt <= new Date()) {
        await database.webSession.deleteMany({ where: { sid } });
        return callback(null, null);
      }
      callback(null, JSON.parse(record.data));
    }).catch(callback);
  }

  set(sid, value, callback = () => {}) {
    const expiresAt = sessionExpiry(value);
    database.webSession.upsert({
      where: { sid },
      create: { sid, data: JSON.stringify(value), expiresAt },
      update: { data: JSON.stringify(value), expiresAt }
    }).then(() => callback(null), callback);
  }

  touch(sid, value, callback = () => {}) {
    database.webSession.updateMany({ where: { sid }, data: { expiresAt: sessionExpiry(value) } })
      .then(() => callback(null), callback);
  }

  destroy(sid, callback = () => {}) {
    database.webSession.deleteMany({ where: { sid } }).then(() => callback(null), callback);
  }
}

function sessionExpiry(value) {
  const expires = value?.cookie?.expires ? new Date(value.cookie.expires) : null;
  return expires && !Number.isNaN(expires.getTime())
    ? expires
    : new Date(Date.now() + DEFAULT_SESSION_AGE_MS);
}

module.exports = { LowdbSessionStore };
