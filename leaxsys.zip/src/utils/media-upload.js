const multer = require("multer");
const sharp = require("sharp");
const path = require("node:path");
const fs = require("node:fs/promises");
const crypto = require("node:crypto");

const uploadDirectory = path.join(__dirname, "..", "..", "public", "assets", "uploads");
const parser = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024, files: 1, fields: 2, parts: 3 }
}).single("asset");

class MediaUploadError extends Error {
  constructor(translationKey) {
    super(translationKey);
    this.name = "MediaUploadError";
    this.translationKey = translationKey;
  }
}

function parseOwnerMediaUpload(req, res, next) {
  parser(req, res, (error) => {
    if (!error) return next();
    if (error instanceof multer.MulterError) {
      const status = error.code === "LIMIT_FILE_SIZE" ? 413 : 400;
      return res.status(status).render("errors/error", {
        status,
        title: req.t("uploadFailedTitle"),
        message: error.code === "LIMIT_FILE_SIZE" ? req.t("uploadTooLarge") : req.t("uploadInvalidForm")
      });
    }
    next(error);
  });
}

async function saveOwnerMedia(file, typeInput) {
  if (!file?.buffer?.length) throw new MediaUploadError("uploadChooseFile");
  const type = typeInput === "icon" ? "icon" : typeInput === "banner" ? "banner" : null;
  if (!type) throw new MediaUploadError("uploadChooseType");
  let pipeline;
  try {
    pipeline = sharp(file.buffer, {
      failOn: "error",
      limitInputPixels: 25_000_000,
      animated: true
    }).rotate();
    const metadata = await pipeline.metadata();
    if (!["jpeg", "png", "webp"].includes(metadata.format) || (metadata.pages || 1) > 1) {
      throw new MediaUploadError((metadata.pages || 1) > 1 ? "uploadAnimatedImage" : "uploadInvalidImage");
    }
    if (type === "icon" && Math.max(metadata.width || 0, metadata.height || 0) > 4096) {
      throw new MediaUploadError("uploadIconTooLarge");
    }
    const buffer = await pipeline
      .resize({
        width: type === "banner" ? 2000 : 512,
        height: type === "banner" ? 1000 : 512,
        fit: type === "banner" ? "inside" : "contain",
        withoutEnlargement: true
      })
      .webp({ quality: 84, effort: 4 })
      .toBuffer();
    await fs.mkdir(uploadDirectory, { recursive: true });
    const filename = `${type}-${crypto.randomUUID()}.webp`;
    await fs.writeFile(path.join(uploadDirectory, filename), buffer, { flag: "wx", mode: 0o644 });
    return {
      filename,
      path: `/assets/uploads/${filename}`,
      bytes: buffer.length,
      width: metadata.width,
      height: metadata.height
    };
  } catch (error) {
    if (error instanceof MediaUploadError) throw error;
    if (error?.name === "Error" && /unsupported|Input file|heif|svg|vips/i.test(error.message)) {
      throw new MediaUploadError("uploadInvalidImage");
    }
    throw error;
  }
}

async function listOwnerMedia() {
  await fs.mkdir(uploadDirectory, { recursive: true });
  const files = await fs.readdir(uploadDirectory, { withFileTypes: true });
  const matchingFiles = files.filter((file) =>
    file.isFile() && /^(banner|icon)-[0-9a-f-]{36}\.webp$/i.test(file.name)
  );
  const withDates = await Promise.all(matchingFiles.map(async (file) => ({
    file,
    modifiedAt: (await fs.stat(path.join(uploadDirectory, file.name))).mtimeMs
  })));
  return withDates
    .sort((left, right) => right.modifiedAt - left.modifiedAt)
    .slice(0, 100)
    .map(({ file }) => ({
      name: file.name,
      path: `/assets/uploads/${file.name}`,
      type: file.name.startsWith("banner-") ? "banner" : "icon"
    }));
}

module.exports = { MediaUploadError, parseOwnerMediaUpload, saveOwnerMedia, listOwnerMedia };
