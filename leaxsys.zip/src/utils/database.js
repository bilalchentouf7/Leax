const crypto = require("node:crypto");
const fs = require("node:fs/promises");
const path = require("node:path");
const bcrypt = require("bcryptjs");

const collections = {
  user: "users",
  category: "categories",
  service: "services",
  order: "orders",
  orderMessage: "orderMessages",
  payment: "payments",
  activityLog: "activityLogs",
  siteSetting: "siteSettings",
  webSession: "webSessions"
};
const projectRoot = path.join(__dirname, "..", "..");
const primaryKeys = { ...Object.fromEntries(Object.keys(collections).map((model) => [model, "id"])), siteSetting: "key", webSession: "sid" };
const uniqueFields = {
  user: ["email"],
  category: ["slug"],
  service: ["slug"],
  payment: ["orderId"],
  siteSetting: ["key"],
  webSession: ["sid"]
};
const relations = {
  user: {
    orders: { model: "order", foreignKey: "userId", many: true },
    activityLogs: { model: "activityLog", foreignKey: "userId", many: true }
  },
  category: { services: { model: "service", foreignKey: "categoryId", many: true } },
  service: {
    category: { model: "category", localKey: "categoryId" },
    orders: { model: "order", foreignKey: "serviceId", many: true }
  },
  order: {
    user: { model: "user", localKey: "userId" },
    service: { model: "service", localKey: "serviceId" },
    payment: { model: "payment", foreignKey: "orderId" },
    messages: { model: "orderMessage", foreignKey: "orderId", many: true }
  },
  orderMessage: {
    sender: { model: "user", localKey: "senderId" },
    order: { model: "order", localKey: "orderId" }
  },
  payment: { order: { model: "order", localKey: "orderId" } },
  activityLog: { user: { model: "user", localKey: "userId" } }
};

const initialData = Object.fromEntries(Object.values(collections).map((name) => [name, []]));
let store = null;
let writeQueue = Promise.resolve();
let mongoClient = null;
let databaseProviderOverride = null;
let databasePath = process.env.DATA_FILE
  ? path.resolve(projectRoot, process.env.DATA_FILE)
  : path.join(projectRoot, "DB", "leaxsys.json");

function getStore() {
  if (!store) throw new Error("Database is not initialized. Start the app through src/server.js first.");
  return store;
}

function getRows(model) {
  const rows = getStore().data[collections[model]];
  if (!Array.isArray(rows)) throw new Error(`Database collection "${collections[model]}" is unavailable.`);
  return rows;
}

function makeId() {
  return crypto.randomBytes(12).toString("base64url");
}

function normalizeDates(value) {
  if (Array.isArray(value)) return value.map(normalizeDates);
  if (!value || typeof value !== "object") return value;
  if (value instanceof Date) return value;
  const result = {};
  for (const [key, item] of Object.entries(value)) {
    result[key] = typeof item === "string" && /(?:At|Date)$/.test(key) && !Number.isNaN(Date.parse(item))
      ? new Date(item)
      : normalizeDates(item);
  }
  return result;
}

function clone(value) {
  return value === undefined ? undefined : structuredClone(value);
}

function keyValue(value) {
  return value instanceof Date ? value.getTime() : value;
}

function compareValues(left, right) {
  if (left instanceof Date || right instanceof Date) {
    const a = left instanceof Date ? left.getTime() : Date.parse(left);
    const b = right instanceof Date ? right.getTime() : Date.parse(right);
    if (Number.isNaN(a) || Number.isNaN(b)) return 0;
    return a < b ? -1 : a > b ? 1 : 0;
  }
  const a = keyValue(left);
  const b = keyValue(right);
  if (a === b) return 0;
  if (a === null || a === undefined) return -1;
  if (b === null || b === undefined) return 1;
  if (typeof a === "number" && typeof b === "number") return a < b ? -1 : 1;
  const leftString = String(a);
  const rightString = String(b);
  return leftString < rightString ? -1 : leftString > rightString ? 1 : 0;
}

async function matches(model, document, where = {}) {
  if (!where || !Object.keys(where).length) return true;
  for (const [field, condition] of Object.entries(where)) {
    if (field === "AND") {
      const conditions = Array.isArray(condition) ? condition : [condition];
      if (!(await Promise.all(conditions.map((item) => matches(model, document, item)))).every(Boolean)) return false;
      continue;
    }
    if (field === "OR") {
      const conditions = Array.isArray(condition) ? condition : [condition];
      if (!(await Promise.all(conditions.map((item) => matches(model, document, item)))).some(Boolean)) return false;
      continue;
    }
    if (field === "NOT") {
      const conditions = Array.isArray(condition) ? condition : [condition];
      if ((await Promise.all(conditions.map((item) => matches(model, document, item)))).some(Boolean)) return false;
      continue;
    }

    const relation = relations[model]?.[field];
    if (relation) {
      const relatedRows = relation.many && relation.foreignKey
        ? getRows(relation.model).filter((row) => row[relation.foreignKey] === document[primaryKeys[model]])
        : relation.foreignKey
          ? getRows(relation.model).filter((row) => row[relation.foreignKey] === document[primaryKeys[model]])
          : getRows(relation.model).filter((row) => row[primaryKeys[relation.model]] === document[relation.localKey]);
      if (relation.many) {
        const filters = condition || {};
        for (const [quantifier, nestedWhere] of Object.entries(filters)) {
          const outcomes = await Promise.all(relatedRows.map((row) => matches(relation.model, row, nestedWhere)));
          if (quantifier === "some" && !outcomes.some(Boolean)) return false;
          if (quantifier === "none" && outcomes.some(Boolean)) return false;
          if (quantifier === "every" && !outcomes.every(Boolean)) return false;
        }
      } else {
        const related = relatedRows[0];
        if (condition === null ? Boolean(related) : !related || !(await matches(relation.model, related, condition))) return false;
      }
      continue;
    }

    const actual = document[field];
    if (!matchValue(actual, condition)) return false;
  }
  return true;
}

function matchValue(actual, condition) {
  if (!condition || typeof condition !== "object" || condition instanceof Date || Array.isArray(condition)) {
    return equalValues(actual, condition);
  }
  const recognized = ["equals", "in", "notIn", "not", "contains", "startsWith", "endsWith", "gt", "gte", "lt", "lte"];
  const operators = Object.keys(condition).filter((key) => recognized.includes(key));
  if (!operators.length) return equalValues(actual, condition);
  return operators.every((operator) => {
    const expected = condition[operator];
    switch (operator) {
      case "equals": return equalValues(actual, expected);
      case "in": return expected.some((item) => equalValues(actual, item));
      case "notIn": return !expected.some((item) => equalValues(actual, item));
      case "not": return expected && typeof expected === "object" && !(expected instanceof Date)
        ? !matchValue(actual, expected)
        : !equalValues(actual, expected);
      case "contains": return typeof actual === "string" && actual.includes(String(expected));
      case "startsWith": return typeof actual === "string" && actual.startsWith(String(expected));
      case "endsWith": return typeof actual === "string" && actual.endsWith(String(expected));
      case "gt": return compareValues(actual, expected) > 0;
      case "gte": return compareValues(actual, expected) >= 0;
      case "lt": return compareValues(actual, expected) < 0;
      case "lte": return compareValues(actual, expected) <= 0;
      default: return false;
    }
  });
}

function equalValues(left, right) {
  if (left instanceof Date || right instanceof Date) {
    const leftDate = left instanceof Date ? left.getTime() : Date.parse(left);
    const rightDate = right instanceof Date ? right.getTime() : Date.parse(right);
    return !Number.isNaN(leftDate) && leftDate === rightDate;
  }
  if (Array.isArray(left) || Array.isArray(right)) return JSON.stringify(left) === JSON.stringify(right);
  return left === right;
}

function sortRows(rows, orderBy = {}) {
  const clauses = Array.isArray(orderBy) ? orderBy : [orderBy];
  return rows.sort((left, right) => {
    for (const clause of clauses) {
      for (const [field, direction] of Object.entries(clause || {})) {
        const order = direction === "desc" ? -1 : 1;
        const comparison = compareValues(left[field], right[field]);
        if (comparison) return comparison * order;
      }
    }
    return 0;
  });
}

function applyWindow(rows, args = {}) {
  const start = Math.max(0, Number(args.skip) || 0);
  const end = args.take === undefined ? undefined : start + Math.max(0, Number(args.take) || 0);
  return rows.slice(start, end);
}

function applySelect(model, document, select) {
  if (!select) return document;
  const selected = {};
  for (const [key, enabled] of Object.entries(select)) {
    if (!enabled) continue;
    if (key === "_count") {
      selected._count = document._count;
    } else if (Object.prototype.hasOwnProperty.call(document, key)) {
      selected[key] = document[key];
    }
  }
  return selected;
}

function countRelations(model, document, selection) {
  const counts = {};
  for (const [relationName, enabled] of Object.entries(selection || {})) {
    if (!enabled) continue;
    const relation = relations[model]?.[relationName];
    if (!relation?.many) throw new Error(`Unknown count relation "${model}.${relationName}".`);
    counts[relationName] = getRows(relation.model).filter((row) =>
      row[relation.foreignKey] === document[primaryKeys[model]]
    ).length;
  }
  return counts;
}

async function populate(model, rawDocument, spec = {}, depth = 0) {
  if (!rawDocument) return null;
  if (depth > 8) throw new Error("Database relation nesting exceeded the supported limit.");
  let document = normalizeDates(clone(rawDocument));
  for (const [field, config] of Object.entries(spec.include || {})) {
    if (field === "_count") {
      document._count = countRelations(model, document, config.select);
      continue;
    }
    const relation = relations[model]?.[field];
    if (!relation) throw new Error(`Unknown database relation "${model}.${field}".`);
    let relatedRows = relation.foreignKey
      ? getRows(relation.model).filter((row) => row[relation.foreignKey] === document[primaryKeys[model]])
      : getRows(relation.model).filter((row) => row[primaryKeys[relation.model]] === document[relation.localKey]);
    const relationSpec = config === true ? {} : config || {};
    if (relationSpec.where) {
      const flags = await Promise.all(relatedRows.map((row) => matches(relation.model, row, relationSpec.where)));
      relatedRows = relatedRows.filter((_, index) => flags[index]);
    }
    if (relation.many) {
      relatedRows = applyWindow(sortRows(relatedRows, relationSpec.orderBy), relationSpec);
      document[field] = await Promise.all(relatedRows.map((row) => populate(relation.model, row, relationSpec, depth + 1)));
    } else {
      document[field] = relatedRows.length
        ? await populate(relation.model, relatedRows[0], relationSpec, depth + 1)
        : null;
    }
  }
  if (spec.select?._count) {
    document._count = countRelations(model, document, spec.select._count.select);
  }
  if (spec.select) {
    for (const [field, config] of Object.entries(spec.select)) {
      if (!config || field === "_count" || Object.prototype.hasOwnProperty.call(document, field)) continue;
      if (relations[model]?.[field]) {
        const included = await populate(model, rawDocument, { include: { [field]: config } }, depth);
        document[field] = included[field];
      }
    }
    document = applySelect(model, document, spec.select);
  }
  return document;
}

async function findMany(model, args = {}) {
  await writeQueue;
  let rows = getRows(model);
  if (args.where) {
    const flags = await Promise.all(rows.map((row) => matches(model, row, args.where)));
    rows = rows.filter((_, index) => flags[index]);
  }
  rows = applyWindow(sortRows(rows, args.orderBy), args);
  return Promise.all(rows.map((row) => populate(model, row, args)));
}

async function findFirst(model, args = {}) {
  return (await findMany(model, { ...args, take: 1 }))[0] || null;
}

async function findUnique(model, args = {}) {
  return findFirst(model, args);
}

function defaultFields(model, data) {
  const now = new Date();
  const result = { ...data };
  if (primaryKeys[model] === "id" && !result.id) result.id = makeId();
  if (model === "user") Object.assign(result, { role: "USER", active: true, lastLoginAt: null, ...result });
  if (model === "category") Object.assign(result, { active: true, displayOrder: 0, ...result });
  if (model === "service") Object.assign(result, { active: true, featured: false, displayOrder: 0, currency: "USD", pricingModel: "FIXED", ...result });
  if (model === "order") Object.assign(result, {
    status: "PENDING", paymentStatus: "UNPAID", amount: 0, currency: "USD",
    contactEmail: "", contactPhone: null, clientAcceptedAt: null, ownerAcceptedAt: null, ...result
  });
  if (model === "payment") Object.assign(result, { status: "PENDING", ...result });
  if (["user", "category", "service", "order", "orderMessage", "payment", "activityLog"].includes(model) && !result.createdAt) {
    result.createdAt = now;
  }
  if (["user", "category", "service", "order", "siteSetting"].includes(model)) result.updatedAt = result.updatedAt || now;
  return result;
}

function validateUnique(model, data, exceptKeyValue) {
  const fields = [...new Set([primaryKeys[model], ...(uniqueFields[model] || [])])];
  for (const field of fields) {
    if (data[field] === null || data[field] === undefined) continue;
    if (getRows(model).some((row) =>
      row[field] === data[field] && row[primaryKeys[model]] !== exceptKeyValue
    )) {
      const error = new Error(`Unique constraint failed on ${model}.${field}.`);
      error.code = "P2002";
      error.meta = { target: [field] };
      throw error;
    }
  }
}

function serializeWrite(operation) {
  const pending = writeQueue.then(async () => {
    const activeStore = getStore();
    const snapshot = clone(activeStore.data);
    try {
      const result = await operation();
      await activeStore.write();
      return result;
    } catch (error) {
      activeStore.data = snapshot;
      throw error;
    }
  });
  writeQueue = pending.catch(() => {});
  return pending;
}

function createModel(model) {
  return {
    async findMany(args) { return findMany(model, args); },
    async findFirst(args) { return findFirst(model, args); },
    async findUnique(args) { return findUnique(model, args); },
    async count(args = {}) {
      await writeQueue;
      const rows = getRows(model);
      if (!args.where) return rows.length;
      const flags = await Promise.all(rows.map((row) => matches(model, row, args.where)));
      return flags.filter(Boolean).length;
    },
    async create(args = {}) {
      const data = defaultFields(model, args.data || {});
      const created = await serializeWrite(() => {
        validateUnique(model, data);
        getRows(model).push(data);
        return clone(data);
      });
      return populate(model, created, args);
    },
    async update(args = {}) {
      const key = primaryKeys[model];
      const updated = await serializeWrite(() => {
        const rows = getRows(model);
        const index = rows.findIndex((row) => matchesPrimary(row, args.where, key));
        if (index < 0) throw missingRecord(model);
        const current = rows[index];
        const data = { ...current, ...(args.data || {}) };
        if (["user", "category", "service", "order", "siteSetting"].includes(model)) data.updatedAt = new Date();
        validateUnique(model, data, current[key]);
        rows[index] = data;
        return clone(data);
      });
      return populate(model, updated, args);
    },
    async updateMany(args = {}) {
      const count = await serializeWrite(async () => {
        const rows = getRows(model);
        let changed = 0;
        for (let index = 0; index < rows.length; index += 1) {
          if (args.where && !(await matches(model, rows[index], args.where))) continue;
          const data = { ...rows[index], ...(args.data || {}) };
          if (["user", "category", "service", "order", "siteSetting"].includes(model)) data.updatedAt = new Date();
          validateUnique(model, data, rows[index][primaryKeys[model]]);
          rows[index] = data;
          changed += 1;
        }
        return changed;
      });
      return { count };
    },
    async delete(args = {}) {
      const deleted = await serializeWrite(() => {
        const rows = getRows(model);
        const index = rows.findIndex((row) => matchesPrimary(row, args.where, primaryKeys[model]));
        if (index < 0) throw missingRecord(model);
        return clone(rows.splice(index, 1)[0]);
      });
      return populate(model, deleted, args);
    },
    async deleteMany(args = {}) {
      const count = await serializeWrite(async () => {
        const rows = getRows(model);
        const flags = await Promise.all(rows.map((row) => args.where ? matches(model, row, args.where) : true));
        const remaining = rows.filter((_, index) => !flags[index]);
        const deleted = rows.length - remaining.length;
        getStore().data[collections[model]] = remaining;
        return deleted;
      });
      return { count };
    },
    async upsert(args = {}) {
      const key = primaryKeys[model];
      const record = await serializeWrite(async () => {
        const rows = getRows(model);
        const matchingRows = await Promise.all(rows.map((row) => matches(model, row, args.where)));
        const index = matchingRows.indexOf(true);
        if (index >= 0) {
          const current = rows[index];
          const data = { ...current, ...(args.update || {}) };
          if (["user", "category", "service", "order", "siteSetting"].includes(model)) data.updatedAt = new Date();
          validateUnique(model, data, current[key]);
          rows[index] = data;
          return clone(data);
        }
        const data = defaultFields(model, args.create || {});
        validateUnique(model, data);
        rows.push(data);
        return clone(data);
      });
      return populate(model, record, args);
    },
    async groupBy(args = {}) {
      await writeQueue;
      const rows = await findMany(model, { where: args.where });
      const fields = Array.isArray(args.by) ? args.by : [args.by].filter(Boolean);
      const groups = new Map();
      for (const row of rows) {
        const values = Object.fromEntries(fields.map((field) => [field, row[field]]));
        const groupKey = JSON.stringify(values, (_, value) => value instanceof Date ? value.toISOString() : value);
        if (!groups.has(groupKey)) groups.set(groupKey, { ...values, _rows: [] });
        groups.get(groupKey)._rows.push(row);
      }
      let result = [...groups.values()].map((group) => {
        const output = Object.fromEntries(Object.entries(group).filter(([key]) => key !== "_rows"));
        if (args._count) {
          output._count = {};
          for (const [field, enabled] of Object.entries(args._count)) {
            if (enabled) output._count[field] = group._rows.length;
          }
        }
        if (args._sum) {
          output._sum = {};
          for (const field of Object.keys(args._sum)) {
            output._sum[field] = group._rows.reduce((sum, row) => sum + (Number(row[field]) || 0), 0);
          }
        }
        return output;
      });
      if (args.orderBy) {
        const clauses = Array.isArray(args.orderBy) ? args.orderBy : [args.orderBy];
        result.sort((left, right) => {
          for (const clause of clauses) {
            for (const [field, instruction] of Object.entries(clause)) {
              const nested = instruction && typeof instruction === "object" ? Object.keys(instruction)[0] : null;
              const direction = nested ? instruction[nested] : instruction;
              const a = nested ? left[field]?.[nested] : left[field];
              const b = nested ? right[field]?.[nested] : right[field];
              const comparison = compareValues(a, b) * (direction === "desc" ? -1 : 1);
              if (comparison) return comparison;
            }
          }
          return 0;
        });
      }
      return applyWindow(result, args);
    }
  };
}

function matchesPrimary(row, where = {}, key) {
  return Object.prototype.hasOwnProperty.call(where, key) && row[key] === where[key];
}

function missingRecord(model) {
  const error = new Error(`No ${model} record was found for the requested operation.`);
  error.code = "P2025";
  return error;
}

const database = Object.fromEntries(Object.keys(collections).map((model) => [model, createModel(model)]));

function createMongoAdapter(stateCollection) {
  const collectionNames = Object.values(collections);
  return {
    async read() {
      const documents = await stateCollection.find({ _id: { $in: collectionNames } }).toArray();
      if (!documents.length) return null;
      if (documents.length !== collectionNames.length) {
        throw new Error("MongoDB application state is incomplete; refusing to initialize missing collections.");
      }
      const data = clone(initialData);
      for (const document of documents) {
        if (!collectionNames.includes(document._id) || !Array.isArray(document.records)) {
          throw new Error(`Invalid MongoDB state document "${document._id}".`);
        }
        data[document._id] = document.records;
      }
      return data;
    },
    async write(data) {
      const operations = collectionNames.map((name) => {
        if (!Array.isArray(data[name])) {
          throw new Error(`Database collection "${name}" must be an array.`);
        }
        return {
          replaceOne: {
            filter: { _id: name },
            replacement: { _id: name, records: data[name] },
            upsert: true
          }
        };
      });
      await stateCollection.bulkWrite(operations, { ordered: true });
    }
  };
}

function safeMongoErrorMessage(message) {
  return String(message).replace(/mongodb(?:\+srv)?:\/\/\S+/gi, "[redacted MongoDB URI]");
}

async function connectDatabase() {
  if (store) return;
  const [{ Low }, { DataFile }] = await Promise.all([
    import("lowdb"),
    import("lowdb/node")
  ]);
  const provider = String(databaseProviderOverride || process.env.DATABASE_PROVIDER || "mongodb").toLowerCase();
  if (!["json", "mongodb"].includes(provider)) {
    throw new Error('DATABASE_PROVIDER must be either "json" or "mongodb".');
  }

  let adapter;
  if (provider === "mongodb") {
    const uri = String(process.env.MONGODB_URI || "").trim();
    if (!uri) throw new Error("MONGODB_URI is required when DATABASE_PROVIDER=mongodb.");
    const { MongoClient } = await import("mongodb");
    let client;
    try {
      client = new MongoClient(uri, { serverSelectionTimeoutMS: 10000 });
      await client.connect();
      const databaseName = String(process.env.MONGODB_DATABASE || "").trim() || undefined;
      adapter = createMongoAdapter(client.db(databaseName).collection("leaxsys_state"));
      mongoClient = client;
    } catch (error) {
      if (client) await client.close().catch(() => {});
      throw new Error(`MongoDB connection failed: ${safeMongoErrorMessage(error.message)}`);
    }
  } else {
    const absolutePath = path.resolve(databasePath);
    await fs.mkdir(path.dirname(absolutePath), { recursive: true });
    // Tolerate a UTF-8 BOM: files edited or restored on Windows may start with one,
    // and JSON.parse would otherwise fail startup.
    adapter = new DataFile(absolutePath, {
      parse: (text) => JSON.parse(String(text).replace(/^\uFEFF/, "")),
      stringify: (data) => JSON.stringify(data, null, 2)
    });
  }

  const lowdb = new Low(adapter, clone(initialData));
  try {
    await lowdb.read();
    if (lowdb.data === null) lowdb.data = clone(initialData);
    for (const [model, collection] of Object.entries(collections)) {
      if (!Array.isArray(lowdb.data[collection])) {
        throw new Error(`Invalid database collection "${collection}" for model "${model}".`);
      }
    }
    store = lowdb;
    await lowdb.write();
  } catch (error) {
    store = null;
    if (mongoClient) {
      const client = mongoClient;
      mongoClient = null;
      try {
        await client.close();
      } catch (closeError) {
        throw new Error(
          `MongoDB initialization failed: ${safeMongoErrorMessage(error.message)}; ` +
          `closing the client also failed: ${safeMongoErrorMessage(closeError.message)}`
        );
      }
    }
    if (provider === "mongodb") {
      throw new Error(`MongoDB initialization failed: ${safeMongoErrorMessage(error.message)}`);
    }
    throw error;
  }
}

async function closeDatabase() {
  await writeQueue;
  store = null;
  if (mongoClient) {
    const client = mongoClient;
    mongoClient = null;
    await client.close();
  }
}

async function initializeOwner() {
  const email = String(process.env.OWNER_EMAIL || "").trim().toLowerCase();
  const password = String(process.env.OWNER_PASSWORD || "");
  const name = String(process.env.OWNER_NAME || "Bilal Chentouf").trim().slice(0, 80);
  if (!email || !password) return false;
  const existing = await database.user.findUnique({ where: { email } });
  if (existing) return existing.role === "OWNER";
  if (Buffer.byteLength(password, "utf8") < 14 || Buffer.byteLength(password, "utf8") > 72) {
    throw new Error("OWNER_PASSWORD must be between 14 and 72 UTF-8 bytes.");
  }
  await database.user.create({
    data: {
      name: name || "Bilal Chentouf",
      email,
      passwordHash: await bcrypt.hash(password, 12),
      role: "OWNER",
      active: true
    }
  });
  return true;
}

const databaseInternals = {
  collections,
  matches,
  sortRows,
  normalizeDates,
  createMongoAdapter,
  setDatabasePathForTests(value) {
    if (store || mongoClient) throw new Error("Close the database before changing its test path.");
    databasePath = value;
    databaseProviderOverride = "json";
  }
};

module.exports = { database, connectDatabase, closeDatabase, initializeOwner, databaseInternals };
