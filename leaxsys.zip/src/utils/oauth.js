const OAuth2Strategy = require("passport-oauth2");
const { database } = require("./database");

const definitions = {
  github: {
    clientId: "GITHUB_CLIENT_ID",
    clientSecret: "GITHUB_CLIENT_SECRET",
    authorizationURL: "https://github.com/login/oauth/authorize",
    tokenURL: "https://github.com/login/oauth/access_token",
    scopes: ["read:user", "user:email"],
    idField: "githubId",
    async profile(accessToken) {
      const [user, emails] = await Promise.all([
        oauthJson("https://api.github.com/user", accessToken),
        oauthJson("https://api.github.com/user/emails", accessToken)
      ]);
      const verified = emails.find((email) => email.primary && email.verified)
        || emails.find((email) => email.verified);
      return {
        id: user.id ? String(user.id) : "",
        name: user.name || user.login,
        email: verified?.email || "",
        verified: Boolean(verified)
      };
    }
  },
  discord: {
    clientId: "DISCORD_CLIENT_ID",
    clientSecret: "DISCORD_CLIENT_SECRET",
    authorizationURL: "https://discord.com/oauth2/authorize",
    tokenURL: "https://discord.com/api/oauth2/token",
    scopes: ["identify", "email"],
    idField: "discordId",
    async profile(accessToken) {
      const data = await oauthJson("https://discord.com/api/users/@me", accessToken);
      return {
        id: data.id,
        name: data.global_name || data.username,
        email: data.email,
        verified: data.verified === true
      };
    }
  }
};

const providers = Object.fromEntries(
  Object.entries(definitions).map(([name, definition]) => {
    const clientId = process.env[definition.clientId] || "";
    const clientSecret = process.env[definition.clientSecret] || "";
    if (Boolean(clientId) !== Boolean(clientSecret)) {
      throw new Error(`${definition.clientId} and ${definition.clientSecret} must both be configured.`);
    }
    return [name, { ...definition, enabled: Boolean(clientId) }];
  })
);

function configureOAuth(passport) {
  const baseUrl = (process.env.BASE_URL || `http://localhost:${process.env.PORT || 3000}`).replace(/\/+$/, "");
  for (const [name, provider] of Object.entries(providers)) {
    if (!provider.enabled) continue;
    const strategy = new OAuth2Strategy({
      authorizationURL: provider.authorizationURL,
      tokenURL: provider.tokenURL,
      clientID: process.env[provider.clientId],
      clientSecret: process.env[provider.clientSecret],
      callbackURL: `${baseUrl}/auth/${name}/callback`,
      scope: provider.scopes,
      state: true,
      pkce: "S256",
      customHeaders: { "User-Agent": "LeaxSys/1.0", Accept: "application/json" }
    }, async (accessToken, refreshToken, profile, done) => {
      try {
        const user = await resolveOAuthUser(provider, profile);
        done(null, user || false);
      } catch (error) {
        done(error);
      }
    });
    strategy.userProfile = (accessToken, done) =>
      provider.profile(accessToken).then((identity) => done(null, identity)).catch(done);
    passport.use(name, strategy);
  }
  return providers;
}

async function resolveOAuthUser(provider, identity) {
  if (!identity.id || !identity.email || !identity.verified) return null;
  const email = identity.email.trim().toLowerCase();
  const existingIdentity = await database.user.findUnique({
    where: { [provider.idField]: identity.id }
  });
  if (existingIdentity) return existingIdentity.active ? existingIdentity : null;

  const emailAccount = await database.user.findUnique({ where: { email } });
  if (emailAccount) {
    if (!emailAccount.active) return null;
    return database.user.update({
      where: { id: emailAccount.id },
      data: { [provider.idField]: identity.id, name: emailAccount.name || identity.name || email }
    });
  }
  if (process.env.ENABLE_REGISTRATION !== "true") return null;
  return database.user.create({
    data: {
      email,
      name: String(identity.name || email).trim().slice(0, 80) || email,
      [provider.idField]: identity.id
    }
  });
}

async function oauthJson(url, accessToken) {
  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      Accept: "application/json",
      "User-Agent": "LeaxSys/1.0"
    },
    signal: AbortSignal.timeout(8000)
  });
  if (!response.ok) throw new Error(`OAuth profile request failed with status ${response.status}.`);
  return response.json();
}

module.exports = { configureOAuth, providers };
