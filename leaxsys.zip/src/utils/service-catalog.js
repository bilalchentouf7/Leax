const arabicCatalog = require("../locales/ar-catalog");

function localizeService(service, locale) {
  if (locale !== "ar") return service;
  const translation = arabicCatalog.services[service.slug];
  const hasStoredArabic = [
    service.nameAr, service.shortDescriptionAr, service.descriptionAr,
    service.featuresAr, service.requirementsAr, service.faqsAr, service.deliveryTimeAr
  ].some(Boolean);
  if (!translation && !hasStoredArabic) return service;
  return {
    ...service,
    name: service.nameAr || translation?.name || service.name,
    shortDescription: service.shortDescriptionAr || translation?.shortDescription || service.shortDescription,
    description: service.descriptionAr || translation?.description || service.description,
    features: service.featuresAr ? parseLines(service.featuresAr) : translation?.features || service.features,
    requirements: service.requirementsAr ? parseLines(service.requirementsAr) : translation?.requirements || service.requirements,
    faqs: service.faqsAr ? parseFaqs(service.faqsAr) : translation?.faqs || service.faqs,
    deliveryTime: service.deliveryTimeAr || translation?.deliveryTime || service.deliveryTime,
    category: service.category ? localizeCategory(service.category, locale) : service.category
  };
}

function parseLines(value) {
  return String(value).split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
}

function parseFaqs(value) {
  return String(value).split(/\r?\n/).map((line) => {
    const separator = line.indexOf("|");
    return separator < 0 ? null : {
      question: line.slice(0, separator).trim(),
      answer: line.slice(separator + 1).trim()
    };
  }).filter((item) => item && item.question && item.answer);
}

function localizeCategory(category, locale) {
  if (locale !== "ar") return category;
  const name = arabicCatalog.categories[category.slug];
  return name ? { ...category, name } : category;
}

module.exports = { localizeService, localizeCategory };
