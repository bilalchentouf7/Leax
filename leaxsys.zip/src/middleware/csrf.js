const crypto = require("node:crypto");

function attachCsrfToken(req, res, next) {
  if (!req.session.csrfToken) {
    req.session.csrfToken = crypto.randomBytes(32).toString("hex");
    return req.session.save((error) => {
      if (error) return next(error);
      res.locals.csrfToken = req.session.csrfToken;
      next();
    });
  }
  res.locals.csrfToken = req.session.csrfToken;
  next();
}

function csrfProtection(req, res, next) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  const supplied = req.get("x-csrf-token") || req.body?._csrf;
  const expected = req.session.csrfToken;
  if (!supplied || !expected) return res.status(403).send("Invalid CSRF token");
  const left = Buffer.from(String(supplied));
  const right = Buffer.from(String(expected));
  if (left.length !== right.length || !crypto.timingSafeEqual(left, right)) {
    return res.status(403).send("Invalid CSRF token");
  }
  next();
}

module.exports = { attachCsrfToken, csrfProtection };
