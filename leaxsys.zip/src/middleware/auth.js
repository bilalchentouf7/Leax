const { database } = require("../utils/database");

async function loadUser(req, res, next) {
  try {
    req.user = req.session.userId
      ? await database.user.findUnique({ where: { id: req.session.userId } })
      : null;
    if (req.user && !req.user.active) {
      req.session.destroy(() => {});
      req.user = null;
    }
    res.locals.user = req.user;
    next();
  } catch (error) {
    next(error);
  }
}

function requireAuth(req, res, next) {
  if (!req.user) return res.redirect(`/login?next=${encodeURIComponent(req.originalUrl)}`);
  next();
}

function requireOwner(req, res, next) {
  if (!req.user) return res.redirect(`/login?next=${encodeURIComponent(req.originalUrl)}`);
  if (req.user.role !== "OWNER") {
    return res.status(403).render("errors/error", {
      status: 403,
      title: req.t("forbiddenTitle"),
      message: req.t("forbiddenMessage")
    });
  }
  next();
}

module.exports = { loadUser, requireAuth, requireOwner };
