const dictionaries = {
  en: require("../locales/en"),
  ar: require("../locales/ar")
};

function localeMiddleware(req, res, next) {
  const requested = req.query.lang;
  const cookieHeader = String(req.headers.cookie || "");
  const languageCookie = cookieHeader.split(";").map((part) => part.trim()).find((part) => part.startsWith("leaxsys_lang="));
  const cookie = languageCookie ? decodeURIComponent(languageCookie.slice("leaxsys_lang=".length)) : null;
  const locale = ["en", "ar"].includes(requested) ? requested
    : ["en", "ar"].includes(cookie) ? cookie
      : "en";
  req.locale = locale;
  req.t = (key) => dictionaries[locale][key] || dictionaries.en[key] || key;
  res.locals.locale = locale;
  res.locals.dir = locale === "ar" ? "rtl" : "ltr";
  res.locals.t = req.t;
  if (requested && ["en", "ar"].includes(requested)) {
    res.cookie("leaxsys_lang", requested, { sameSite: "lax", maxAge: 31536000000 });
  }
  next();
}

module.exports = { localeMiddleware };
