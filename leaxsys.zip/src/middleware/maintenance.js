const { database } = require("../utils/database");

let cachedValue = false;
let cacheExpiresAt = 0;
async function isMaintenanceEnabled() {
  if (Date.now() < cacheExpiresAt) return cachedValue;
  const setting = await database.siteSetting.findUnique({
    where: { key: "maintenanceMode" },
    select: { value: true }
  });
  cachedValue = setting?.value === "true";
  cacheExpiresAt = Date.now() + 5000;
  return cachedValue;
}

function clearMaintenanceCache() {
  cacheExpiresAt = 0;
}

async function maintenanceMiddleware(req, res, next) {
  try {
    if (!await isMaintenanceEnabled()
      || req.user?.role === "OWNER"
      || req.path === "/login"
      || req.path === "/logout"
      || req.path.startsWith("/auth/")) {
      return next();
    }
    res.status(503).render("pages/maintenance");
  } catch (error) {
    next(error);
  }
}

module.exports = { maintenanceMiddleware, clearMaintenanceCache };
