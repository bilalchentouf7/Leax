require("dotenv").config();

const { createApp } = require("./app");
const { logger } = require("./utils/logger");
const { connectDatabase, closeDatabase, initializeOwner } = require("./utils/database");
const { initializeServiceCatalog } = require("./utils/service-seed");

const port = Number(process.env.PORT || 3000);

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error("SESSION_SECRET must be set to at least 32 characters.");
}

let server;
connectDatabase().then(initializeServiceCatalog).then(initializeOwner).then((ownerReady) => {
  if (!ownerReady) logger.warn("No owner account created. Set OWNER_EMAIL and OWNER_PASSWORD to bootstrap the owner on next restart.");
  const app = createApp();
  server = app.listen(port, () => logger.info({ port }, "LeaxSys is listening"));
  server.on("error", closeServer);
}).catch((error) => {
  logger.error({ err: error }, "Application initialization failed");
  process.exitCode = 1;
});

function closeServer(error) {
  if (error) {
    logger.error({ err: error, port }, "LeaxSys could not bind its HTTP port");
    closeDatabase().catch((closeError) => logger.error({ err: closeError }, "Database shutdown failed"));
    process.exitCode = 1;
  }
}

async function shutdown(signal) {
  logger.info({ signal }, "Shutting down");
  if (server) server.close((error) => {
    closeServer(error);
    closeDatabase().catch((closeError) => logger.error({ err: closeError }, "Database shutdown failed"));
  });
  else closeDatabase().catch((error) => logger.error({ err: error }, "Database shutdown failed"));
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
