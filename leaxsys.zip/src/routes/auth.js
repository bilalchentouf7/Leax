const express = require("express");
const bcrypt = require("bcryptjs");
const { rateLimit } = require("express-rate-limit");
const { z } = require("zod");
const { database } = require("../utils/database");
const { requireAuth } = require("../middleware/auth");
const passport = require("passport");
const { providers } = require("../utils/oauth");

const authRouter = express.Router();
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false
});
const credentials = z.object({
  email: z.string().email().max(254).transform((value) => value.toLowerCase()),
  password: z.string().min(10).max(128)
    .refine((value) => Buffer.byteLength(value, "utf8") <= 72, "Password is too long.")
});

authRouter.get("/login", (req, res) => {
  if (req.user) return res.redirect(req.user.role === "OWNER" ? "/owner" : "/dashboard");
  res.render("pages/login", {
    mode: "login",
    nextPath: safeNext(req.query.next),
    error: req.query.oauth === "failed" ? "OAuth sign-in failed. Use a verified provider email or contact the platform owner." : null
  });
});

authRouter.get("/auth/:provider", (req, res, next) => {
  const provider = req.params.provider;
  if (!providers[provider]?.enabled) return res.status(404).render("errors/error", {
    status: 404, title: req.t("notFoundTitle"), message: req.t("notFoundMessage")
  });
  passport.authenticate(provider)(req, res, next);
});

authRouter.get("/auth/:provider/callback", (req, res, next) => {
  const provider = req.params.provider;
  if (!providers[provider]?.enabled) return res.status(404).render("errors/error", {
    status: 404, title: req.t("notFoundTitle"), message: req.t("notFoundMessage")
  });
  passport.authenticate(provider, (error, user) => {
    if (error) return next(error);
    if (!user) return res.redirect("/login?oauth=failed");
    req.session.regenerate(async (sessionError) => {
      if (sessionError) return next(sessionError);
      req.session.userId = user.id;
      try {
        await database.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
        await database.activityLog.create({
          data: {
            userId: user.id,
            action: `OAUTH_LOGIN_${provider.toUpperCase()}`,
            ipAddress: req.ip,
            userAgent: String(req.get("user-agent") || "").slice(0, 500)
          }
        });
        res.redirect(user.role === "OWNER" ? "/owner" : "/dashboard");
      } catch (logError) {
        next(logError);
      }
    });
  })(req, res, next);
});

authRouter.post("/login", async (req, res, next) => {
  try {
    const parsed = credentials.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).render("pages/login", {
        mode: "login", nextPath: safeNext(req.body.next), error: req.t("authFailed")
      });
    }
    const user = await database.user.findUnique({ where: { email: parsed.data.email } });
    if (!user || !user.passwordHash || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) {
      await database.activityLog.create({
        data: { action: "LOGIN_FAILED", target: parsed.data.email, ipAddress: req.ip }
      });
      return res.status(401).render("pages/login", {
        mode: "login", nextPath: safeNext(req.body.next), error: req.t("authFailed")
      });
    }
    if (!user.active) {
      return res.status(403).render("pages/login", {
        mode: "login", nextPath: safeNext(req.body.next), error: req.t("accountDisabled")
      });
    }
    await new Promise((resolve, reject) => req.session.regenerate((error) => error ? reject(error) : resolve()));
    req.session.userId = user.id;
    await database.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    await database.activityLog.create({
      data: {
        userId: user.id, action: "LOGIN", ipAddress: req.ip,
        userAgent: String(req.get("user-agent") || "").slice(0, 500)
      }
    });
    res.redirect(safeNext(req.body.next) || (user.role === "OWNER" ? "/owner" : "/dashboard"));
  } catch (error) {
    next(error);
  }
});

authRouter.get("/register", (req, res) => {
  if (process.env.ENABLE_REGISTRATION !== "true") {
    return res.status(403).render("errors/error", {
      status: 403, title: req.t("forbiddenTitle"), message: req.t("registrationDisabled")
    });
  }
  res.render("pages/login", { mode: "register", nextPath: "" });
});

authRouter.post("/register", async (req, res, next) => {
  try {
    if (process.env.ENABLE_REGISTRATION !== "true") {
      return res.status(403).render("errors/error", {
        status: 403, title: req.t("forbiddenTitle"), message: req.t("registrationDisabled")
      });
    }
    const parsed = credentials.extend({ name: z.string().trim().min(2).max(80) }).safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).render("pages/login", {
        mode: "register", nextPath: "", error: "Enter a valid name, email, and password (minimum 10 characters)."
      });
    }
    const user = await database.user.create({
      data: {
        name: parsed.data.name,
        email: parsed.data.email,
        passwordHash: await bcrypt.hash(parsed.data.password, 12)
      }
    });
    await new Promise((resolve, reject) => req.session.regenerate((error) => error ? reject(error) : resolve()));
    req.session.userId = user.id;
    await database.activityLog.create({ data: { userId: user.id, action: "ACCOUNT_CREATED", ipAddress: req.ip } });
    res.redirect("/dashboard");
  } catch (error) {
    next(error);
  }
});

authRouter.post("/logout", requireAuth, (req, res, next) => {
  const userId = req.user.id;
  req.session.destroy(async (error) => {
    if (error) return next(error);
    res.clearCookie("leaxsys.sid");
    try {
      await database.activityLog.create({ data: { userId, action: "LOGOUT", ipAddress: req.ip } });
      res.redirect("/");
    } catch (logError) {
      next(logError);
    }
  });
});

function safeNext(value) {
  return typeof value === "string" && value.startsWith("/") && !value.startsWith("//") ? value : "";
}

module.exports = { authRouter, authLimiter };
