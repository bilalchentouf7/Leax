const express = require("express");
const { database } = require("../utils/database");
const { requireAuth } = require("../middleware/auth");
const { localizeService, localizeCategory } = require("../utils/service-catalog");

const publicRouter = express.Router();

publicRouter.get("/", async (req, res, next) => {
  try {
    const services = await database.service.findMany({
      where: { active: true, featured: true, category: { active: true } },
      include: { category: true },
      orderBy: { displayOrder: "asc" },
      take: 5
    });
    res.render("pages/home", { services: services.map((service) => localizeService(service, req.locale)) });
  } catch (error) {
    next(error);
  }
});

publicRouter.get("/services", async (req, res, next) => {
  try {
    const [services, categories] = await Promise.all([
      database.service.findMany({
        where: { active: true, category: { active: true } },
        include: { category: true },
        orderBy: [{ displayOrder: "asc" }, { name: "asc" }]
      }),
      database.category.findMany({ where: { active: true }, orderBy: { displayOrder: "asc" } })
    ]);
    const selectedCategory = String(req.query.category || "");
    const filteredServices = selectedCategory
      ? services.filter((service) => service.categoryId === selectedCategory)
      : services;
    res.render("pages/services", {
      services: filteredServices.map((service) => localizeService(service, req.locale)),
      categories: categories.map((category) => localizeCategory(category, req.locale)),
      selectedCategory
    });
  } catch (error) {
    next(error);
  }
});

publicRouter.get("/about", (req, res) => {
  res.render("pages/about");
});

publicRouter.get("/licenses", (req, res) => {
  res.render("pages/licenses");
});

publicRouter.get("/security-center", (req, res) => {
  res.render("pages/security-center");
});

publicRouter.get("/services/:slug", async (req, res, next) => {
  try {
    const service = await database.service.findFirst({
      where: { slug: req.params.slug, active: true, category: { active: true } },
      include: { category: true }
    });
    if (!service) return res.status(404).render("errors/error", {
      status: 404, title: req.t("notFoundTitle"), message: req.t("notFoundMessage")
    });
    res.render("pages/service-detail", { service: localizeService(service, req.locale) });
  } catch (error) {
    next(error);
  }
});

publicRouter.post("/services/:slug/request", requireAuth, async (req, res, next) => {
  try {
    const service = await database.service.findFirst({
      where: { slug: req.params.slug, active: true, category: { active: true } }
    });
    if (!service) return res.status(404).render("errors/error", {
      status: 404, title: req.t("notFoundTitle"), message: req.t("notFoundMessage")
    });
    const contactPhone = String(req.body.contactPhone || "").trim();
    if (contactPhone && !/^[+0-9().\s-]{7,30}$/.test(contactPhone)) {
      req.session.flash = { type: "error", message: "Enter a valid contact phone number." };
      return res.redirect(`/services/${encodeURIComponent(service.slug)}`);
    }
    const customerNotes = String(req.body.customerNotes || "").trim().slice(0, 4000);
    await database.order.create({
      data: {
        userId: req.user.id,
        serviceId: service.id,
        amount: 0,
        currency: service.currency,
        customerNotes,
        contactEmail: req.user.email,
        contactPhone: contactPhone || null
      }
    });
    await database.activityLog.create({
      data: { userId: req.user.id, action: "ORDER_REQUESTED", target: service.slug, ipAddress: req.ip }
    });
    req.session.flash = { type: "success", message: req.t("requestSent") };
    res.redirect("/dashboard");
  } catch (error) {
    next(error);
  }
});

module.exports = { publicRouter };
