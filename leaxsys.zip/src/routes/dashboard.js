const express = require("express");
const { rateLimit } = require("express-rate-limit");
const { database } = require("../utils/database");
const { requireAuth } = require("../middleware/auth");
const { localizeService, localizeCategory } = require("../utils/service-catalog");

const dashboardRouter = express.Router();
dashboardRouter.use(requireAuth);
const messageLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 60,
  standardHeaders: "draft-7",
  legacyHeaders: false
});

dashboardRouter.get("/", async (req, res, next) => {
  try {
    const [orders, activeOrders, completedOrders, paidTotals, totalOrders, quoteOrders] = await Promise.all([
      database.order.findMany({
        where: { userId: req.user.id },
        include: { service: { include: { category: true } } },
        orderBy: { createdAt: "desc" },
        take: 20
      }),
      database.order.count({ where: { userId: req.user.id, status: { in: ["PENDING", "AWAITING_CLIENT", "PROCESSING"] } } }),
      database.order.count({ where: { userId: req.user.id, status: "COMPLETED" } }),
      database.order.groupBy({
        by: ["currency"],
        where: { userId: req.user.id, paymentStatus: "PAID" },
        _sum: { amount: true }
      }),
      database.order.count({ where: { userId: req.user.id } }),
      database.order.count({
        where: {
          userId: req.user.id,
          service: { pricingModel: { in: ["QUOTE", "MONTHLY"] } },
          status: { in: ["PENDING", "AWAITING_CLIENT", "PROCESSING"] }
        }
      })
    ]);
    res.render("pages/dashboard", {
      orders: orders.map((order) => ({
        ...order,
        service: localizeService({
          ...order.service,
          category: localizeCategory(order.service.category, req.locale)
        }, req.locale)
      })),
      activeOrders,
      completedOrders,
      totalOrders,
      quoteOrders,
      totalSpent: paidTotals.map(({ currency, _sum }) => `${currency} ${Number(_sum.amount || 0).toFixed(2)}`).join(" · ") || "USD 0.00"
    });
  } catch (error) {
    next(error);
  }
});

dashboardRouter.post("/orders/:id/accept", async (req, res, next) => {
  try {
    const order = await database.order.findFirst({
      where: { id: req.params.id, userId: req.user.id }
    });
    if (!order) return notFound(req, res);
    if (order.status !== "AWAITING_CLIENT" || !order.ownerAcceptedAt || order.paymentStatus === "PAID") {
      req.session.flash = { type: "error", message: "This order does not have an offer ready for acceptance." };
      return res.redirect("/dashboard");
    }
    await database.order.update({
      where: { id: order.id },
      data: { status: "PROCESSING", clientAcceptedAt: new Date() }
    });
    await database.activityLog.create({
      data: { userId: req.user.id, action: "ORDER_ACCEPTED", target: order.id, ipAddress: req.ip }
    });
    req.session.flash = { type: "success", message: "Offer accepted. You can now arrange payment." };
    res.redirect("/dashboard");
  } catch (error) {
    next(error);
  }
});

dashboardRouter.get("/orders/:id/messages", async (req, res, next) => {
  try {
    const order = await accessibleOrder(req.params.id, req.user);
    if (!order) return res.status(404).json({ error: "Order not found." });
    const messages = await database.orderMessage.findMany({
      where: { orderId: order.id },
      include: { sender: { select: { id: true, name: true, role: true } } },
      orderBy: { createdAt: "desc" },
      take: 100
    });
    res.json({
      messages: messages.reverse().map((message) => ({
        id: message.id,
        body: message.body,
        createdAt: message.createdAt,
        sender: message.sender
      }))
    });
  } catch (error) {
    next(error);
  }
});

dashboardRouter.post("/orders/:id/messages", messageLimiter, async (req, res, next) => {
  try {
    const order = await accessibleOrder(req.params.id, req.user);
    if (!order) return res.status(404).json({ error: "Order not found." });
    if (["CANCELLED", "COMPLETED", "REFUNDED"].includes(order.status)) {
      return res.status(409).json({ error: "Messaging is closed for this order." });
    }
    const body = String(req.body.body || "").trim();
    if (!body || body.length > 2000) {
      return res.status(400).json({ error: "Message must contain 1–2000 characters." });
    }
    const message = await database.orderMessage.create({
      data: { orderId: order.id, senderId: req.user.id, body },
      include: { sender: { select: { id: true, name: true, role: true } } }
    });
    res.status(201).json({
      message: {
        id: message.id,
        body: message.body,
        createdAt: message.createdAt,
        sender: message.sender
      }
    });
  } catch (error) {
    next(error);
  }
});

async function accessibleOrder(orderId, user) {
  const order = await database.order.findUnique({ where: { id: orderId } });
  return order && (user.role === "OWNER" || order.userId === user.id) ? order : null;
}

function notFound(req, res) {
  return res.status(404).render("errors/error", {
    status: 404, title: req.t("notFoundTitle"), message: req.t("notFoundMessage")
  });
}

module.exports = { dashboardRouter };
