const express = require("express");
const { z } = require("zod");
const { database } = require("../utils/database");
const { toSlug } = require("../utils/slug");
const { requireOwner } = require("../middleware/auth");
const { clearMaintenanceCache } = require("../middleware/maintenance");
const { MediaUploadError, saveOwnerMedia, listOwnerMedia } = require("../utils/media-upload");

const ownerRouter = express.Router();
const serviceInput = z.object({
  name: z.string().trim().min(2).max(100),
  nameAr: z.string().trim().max(100).optional(),
  shortDescription: z.string().trim().min(5).max(240),
  shortDescriptionAr: z.string().trim().max(240).optional(),
  description: z.string().trim().min(10).max(12000),
  descriptionAr: z.string().trim().max(12000).optional(),
  categoryId: z.string().min(1),
  price: z.coerce.number().min(0).max(1000000),
  pricingModel: z.enum(["FIXED", "QUOTE", "MONTHLY"]),
  currency: z.string().trim().length(3).transform((value) => value.toUpperCase()),
  icon: z.string().trim().min(1).max(40),
  iconImage: z.string().trim().max(300)
    .refine((value) => !value || (/^\/assets\/uploads\/icon-[a-f0-9-]{36}\.webp$/i.test(value)))
    .optional().or(z.literal("")),
  image: z.string().trim().max(300)
    .refine((value) => !value || (/^\/assets\/[a-zA-Z0-9/_\-.]+$/.test(value) && !value.includes("..")))
    .optional().or(z.literal("")),
  features: z.string().max(5000).optional(),
  featuresAr: z.string().max(5000).optional(),
  requirements: z.string().max(5000).optional(),
  requirementsAr: z.string().max(5000).optional(),
  faqs: z.string().max(8000).optional().refine((value) =>
    !value || value.split(/\r?\n/).every((line) => !line.trim() || line.includes("|")),
  "Enter each FAQ as a question | answer."),
  faqsAr: z.string().max(8000).optional().refine((value) =>
    !value || value.split(/\r?\n/).every((line) => !line.trim() || line.includes("|")),
  "Enter each Arabic FAQ as a question | answer."),
  deliveryTime: z.string().trim().min(2).max(100),
  deliveryTimeAr: z.string().trim().max(100).optional(),
  displayOrder: z.coerce.number().int().min(0).max(100000),
  featured: z.enum(["true", "false"]).optional(),
  active: z.enum(["true", "false"]).optional()
});
const categoryInput = z.object({
  name: z.string().trim().min(2).max(80),
  description: z.string().trim().max(500),
  icon: z.string().trim().min(1).max(40),
  displayOrder: z.coerce.number().int().min(0).max(100000),
  active: z.enum(["true", "false"]).optional()
});

ownerRouter.use(requireOwner);

ownerRouter.get("/", async (req, res, next) => {
  try {
    const dayStart = new Date();
    dayStart.setHours(0, 0, 0, 0);
    const chartStart = new Date();
    chartStart.setDate(chartStart.getDate() - 6);
    chartStart.setHours(0, 0, 0, 0);
    const [revenue, todayRevenue, totalOrders, pendingOrders, completedOrders, activeServices,
      totalUsers, activity, chartOrders, popularOrders, statusGroups] = await Promise.all([
      database.order.groupBy({
        by: ["currency"],
        where: { paymentStatus: "PAID" },
        _sum: { amount: true }
      }),
      database.order.groupBy({
        by: ["currency"],
        where: { paymentStatus: "PAID", createdAt: { gte: dayStart } },
        _sum: { amount: true }
      }),
      database.order.count(),
      database.order.count({ where: { status: { in: ["PENDING", "AWAITING_CLIENT"] } } }),
      database.order.count({ where: { status: "COMPLETED" } }),
      database.service.count({ where: { active: true } }),
      database.user.count(),
      database.activityLog.findMany({
        include: { user: { select: { name: true, email: true } } },
        orderBy: { createdAt: "desc" },
        take: 10
      }),
      database.order.findMany({
        where: { createdAt: { gte: chartStart } },
        select: { amount: true, currency: true, status: true, paymentStatus: true, createdAt: true, serviceId: true },
        take: 5000
      }),
      database.order.groupBy({
        by: ["serviceId"],
        _count: { serviceId: true },
        orderBy: { _count: { serviceId: "desc" } },
        take: 5
      }),
      database.order.groupBy({ by: ["status"], _count: { status: true } })
    ]);
    const popularServices = popularOrders.length
      ? await database.service.findMany({
        where: { id: { in: popularOrders.map(({ serviceId }) => serviceId) } },
        select: { id: true, name: true }
      })
      : [];
    const serviceNames = new Map(popularServices.map((service) => [service.id, service.name]));
    const chart = Array.from({ length: 7 }, (_, index) => {
      const date = new Date(chartStart);
      date.setDate(chartStart.getDate() + index);
      const key = date.toLocaleDateString("en-CA");
      const daily = chartOrders.filter((order) => order.createdAt.toLocaleDateString("en-CA") === key);
      return {
        label: date.toLocaleDateString(req.locale, { weekday: "short" }),
        orders: daily.length,
        revenue: daily
          .filter((order) => order.paymentStatus === "PAID" && order.currency === "USD")
          .reduce((total, order) => total + Number(order.amount), 0)
      };
    });
    const maxRevenue = Math.max(1, ...chart.map(({ revenue }) => revenue));
    const maxOrders = Math.max(1, ...chart.map(({ orders }) => orders));
    chart.forEach((day) => {
      day.revenueLevel = Math.round((day.revenue / maxRevenue) * 7);
      day.ordersLevel = Math.round((day.orders / maxOrders) * 7);
    });
    const popularMax = Math.max(1, ...popularOrders.map((item) => item._count.serviceId));
    res.render("owner/dashboard", {
      metrics: {
        revenue: currencyTotals(revenue),
        todayRevenue: currencyTotals(todayRevenue),
        totalOrders, pendingOrders, completedOrders, activeServices, totalUsers
      },
      chart,
      popularServices: popularOrders.map((order) => ({
        name: serviceNames.get(order.serviceId) || "Archived service",
        count: order._count.serviceId,
        level: Math.max(1, Math.round((order._count.serviceId / popularMax) * 7))
      })),
      statusDistribution: statusGroups.map((item) => ({ status: item.status, count: item._count.status })),
      activity
    });
  } catch (error) {
    next(error);
  }
});

ownerRouter.get("/services", async (req, res, next) => {
  try {
    const page = positiveInt(req.query.page, 1, 100000);
    const pageSize = 10;
    const search = String(req.query.q || "").trim().slice(0, 100);
    const categoryId = String(req.query.category || "").slice(0, 32);
    const sort = ["name", "price", "createdAt", "displayOrder"].includes(req.query.sort)
      ? req.query.sort
      : "displayOrder";
    const sortDirection = sort === "displayOrder" ? "asc" : sort === "createdAt" ? "desc" : "asc";
    const where = {
      ...(search ? { OR: [{ name: { contains: search } }, { shortDescription: { contains: search } }] } : {}),
      ...(categoryId ? { categoryId } : {})
    };
    const [services, total, categories] = await Promise.all([
      database.service.findMany({
        where,
        include: { category: true },
        orderBy: [{ [sort]: sortDirection }, { id: "asc" }],
        skip: (page - 1) * pageSize,
        take: pageSize
      }),
      database.service.count({ where }),
      database.category.findMany({ orderBy: { displayOrder: "asc" } })
    ]);
    res.render("owner/services", {
      services, categories, search, categoryId, sort, page,
      pageCount: Math.max(1, Math.ceil(total / pageSize)), total,
      reorderEnabled: !search && !categoryId && sort === "displayOrder"
    });
  } catch (error) {
    next(error);
  }
});

ownerRouter.get("/services/new", async (req, res, next) => {
  try {
    const categories = await database.category.findMany({ orderBy: { displayOrder: "asc" } });
    res.render("owner/service-form", {
      service: null, categories, action: "/owner/services",
      selectedCategoryId: String(req.query.categoryId || "")
    });
  } catch (error) {
    next(error);
  }
});

ownerRouter.get("/media", async (req, res, next) => {
  try {
    const assets = await listOwnerMedia();
    res.render("owner/media", { assets });
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/media/upload", async (req, res, next) => {
  try {
    const type = z.enum(["banner", "icon"]).safeParse(req.body.assetType);
    if (!type.success) {
      req.session.flash = { type: "error", message: req.t("uploadChooseType") };
      return res.redirect("/owner/media");
    }
    let saved;
    try {
      saved = await saveOwnerMedia(req.file, type.data);
    } catch (error) {
      if (error instanceof MediaUploadError) {
        req.session.flash = { type: "error", message: req.t(error.translationKey) };
        return res.redirect("/owner/media");
      }
      throw error;
    }
    await logActivity(req, "MEDIA_UPLOADED", `${type.data}:${saved.filename}`);
    req.session.flash = {
      type: "success",
      message: `${req.t("uploadSuccess")} ${saved.path} — ${saved.width}×${saved.height}`
    };
    res.redirect("/owner/media");
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/services", async (req, res, next) => {
  try {
    const input = serviceInput.safeParse(req.body);
    if (!input.success) return renderInvalid(req, res, "/owner/services/new");
    const data = cleanService(input.data);
    const category = await database.category.findUnique({ where: { id: data.categoryId } });
    if (!category) return renderInvalid(req, res, "/owner/services/new");
    const slug = await uniqueSlug("service", data.name);
    const service = await database.service.create({ data: { ...data, slug } });
    await logActivity(req, "SERVICE_CREATED", service.id);
    req.session.flash = { type: "success", message: `${service.name} created.` };
    res.redirect("/owner/services");
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/services/reorder", async (req, res, next) => {
  try {
    const input = z.object({
      ids: z.array(z.string().min(1).max(32)).min(1).max(10),
      offset: z.coerce.number().int().min(0).max(10000)
    }).safeParse(req.body);
    if (!input.success || new Set(input.data?.ids || []).size !== input.data?.ids.length) {
      return res.status(400).json({ error: "Invalid service ordering." });
    }
    const allIds = await database.service.findMany({
      select: { id: true },
      orderBy: [{ displayOrder: "asc" }, { id: "asc" }],
      take: 1000
    });
    if (allIds.length >= 1000) {
      return res.status(409).json({ error: "Drag ordering is unavailable for catalogs larger than 999 services." });
    }
    const expected = allIds.slice(input.data.offset, input.data.offset + input.data.ids.length).map(({ id }) => id);
    const expectedSet = new Set(expected);
    if (expected.length !== input.data.ids.length || input.data.ids.some((id) => !expectedSet.has(id))) {
      return res.status(409).json({ error: "Service order changed. Refresh before reordering again." });
    }
    const reordered = [...allIds.map(({ id }) => id)];
    reordered.splice(input.data.offset, input.data.ids.length, ...input.data.ids);
    await Promise.all(reordered.map((id, index) =>
      database.service.update({ where: { id }, data: { displayOrder: index + 1 } })
    ));
    await logActivity(req, "SERVICE_ORDER_CHANGED", `${reordered.length} services`);
    res.json({ success: true });
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/services/:id/duplicate", async (req, res, next) => {
  try {
    const source = await database.service.findUnique({ where: { id: req.params.id } });
    if (!source) return notFound(req, res);
    const name = `Copy of ${source.name}`.slice(0, 100);
    const slug = await uniqueSlug("service", name);
    const copy = await database.service.create({
      data: {
        name,
        nameAr: source.nameAr,
        slug,
        shortDescription: source.shortDescription,
        shortDescriptionAr: source.shortDescriptionAr,
        description: source.description,
        descriptionAr: source.descriptionAr,
        categoryId: source.categoryId,
        price: source.price,
        pricingModel: source.pricingModel,
        currency: source.currency,
        icon: source.icon,
        iconImage: source.iconImage,
        image: source.image,
        features: source.features,
        featuresAr: source.featuresAr,
        requirements: source.requirements,
        requirementsAr: source.requirementsAr,
        faqs: source.faqs,
        faqsAr: source.faqsAr,
        deliveryTime: source.deliveryTime,
        deliveryTimeAr: source.deliveryTimeAr,
        featured: false,
        active: false,
        displayOrder: source.displayOrder + 1
      }
    });
    await logActivity(req, "SERVICE_DUPLICATED", `${source.id} -> ${copy.id}`);
    req.session.flash = { type: "success", message: `${copy.name} created as a disabled draft.` };
    res.redirect(`/owner/services/${copy.id}/edit`);
  } catch (error) {
    next(error);
  }
});

ownerRouter.get("/services/:id/edit", async (req, res, next) => {
  try {
    const [service, categories] = await Promise.all([
      database.service.findUnique({ where: { id: req.params.id } }),
      database.category.findMany({ orderBy: { displayOrder: "asc" } })
    ]);
    if (!service) return notFound(req, res);
    res.render("owner/service-form", {
      service, categories, action: `/owner/services/${service.id}/edit`
    });
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/services/:id/edit", async (req, res, next) => {
  try {
    const input = serviceInput.safeParse(req.body);
    if (!input.success) return renderInvalid(req, res, `/owner/services/${req.params.id}/edit`);
    const service = await database.service.findUnique({ where: { id: req.params.id } });
    if (!service) return notFound(req, res);
    const data = cleanService(input.data);
    const category = await database.category.findUnique({ where: { id: data.categoryId } });
    if (!category) return renderInvalid(req, res, `/owner/services/${service.id}/edit`);
    await database.service.update({
      where: { id: service.id },
      data: { ...data, slug: data.name === service.name ? service.slug : await uniqueSlug("service", data.name, service.id) }
    });
    await logActivity(req, "SERVICE_UPDATED", service.id);
    req.session.flash = { type: "success", message: `${data.name} updated.` };
    res.redirect("/owner/services");
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/services/:id/banner", async (req, res, next) => {
  try {
    const service = await database.service.findUnique({ where: { id: req.params.id } });
    if (!service) return notFound(req, res);
    let saved;
    try {
      saved = await saveOwnerMedia(req.file, "banner");
    } catch (error) {
      if (error instanceof MediaUploadError) {
        req.session.flash = { type: "error", message: req.t(error.translationKey) };
        return res.redirect(`/owner/services/${service.id}/edit`);
      }
      throw error;
    }
    await database.service.update({ where: { id: service.id }, data: { image: saved.path } });
    await logActivity(req, "SERVICE_BANNER_UPLOADED", `${service.id}:${saved.filename}`);
    req.session.flash = {
      type: "success",
      message: `${req.t("bannerUpdated")} ${saved.path} — ${saved.width}×${saved.height}`
    };
    res.redirect(`/owner/services/${service.id}/edit`);
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/services/:id/delete", async (req, res, next) => {
  try {
    const service = await database.service.findUnique({ where: { id: req.params.id } });
    if (!service) return notFound(req, res);
    const orders = await database.order.count({ where: { serviceId: service.id } });
    if (orders) {
      req.session.flash = { type: "error", message: "Services with order history cannot be deleted. Disable the service instead." };
      return res.redirect("/owner/services");
    }
    await database.service.delete({ where: { id: service.id } });
    await logActivity(req, "SERVICE_DELETED", service.id);
    res.redirect("/owner/services");
  } catch (error) {
    next(error);
  }
});

ownerRouter.get("/categories", async (req, res, next) => {
  try {
    const categories = await database.category.findMany({
      include: { _count: { select: { services: true } } },
      orderBy: { displayOrder: "asc" }
    });
    res.render("owner/categories", { categories });
  } catch (error) {
    next(error);
  }
});

ownerRouter.get("/categories/:id", async (req, res, next) => {
  try {
    const category = await database.category.findUnique({
      where: { id: req.params.id },
      include: {
        services: {
          orderBy: { displayOrder: "asc" },
          include: { _count: { select: { orders: true } } }
        }
      }
    });
    if (!category) return notFound(req, res);
    const serviceIds = category.services.map(({ id }) => id);
    const [orderCount, revenue] = serviceIds.length
      ? await Promise.all([
        database.order.count({ where: { serviceId: { in: serviceIds } } }),
        database.order.groupBy({
          by: ["currency"],
          where: { serviceId: { in: serviceIds }, paymentStatus: "PAID" },
          _sum: { amount: true }
        })
      ])
      : [0, []];
    res.render("owner/category-detail", {
      category,
      activeServices: category.services.filter((service) => service.active).length,
      orderCount,
      revenue: currencyTotals(revenue)
    });
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/categories", async (req, res, next) => {
  try {
    const input = categoryInput.safeParse(req.body);
    if (!input.success) return renderInvalid(req, res, "/owner/categories");
    const data = input.data;
    const category = await database.category.create({
      data: {
        ...data,
        slug: await uniqueSlug("category", data.name),
        active: data.active === "true"
      }
    });
    await logActivity(req, "CATEGORY_CREATED", category.id);
    req.session.flash = { type: "success", message: `${category.name} created.` };
    res.redirect("/owner/categories");
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/categories/:id/edit", async (req, res, next) => {
  try {
    const input = categoryInput.safeParse(req.body);
    if (!input.success) return renderInvalid(req, res, "/owner/categories");
    const current = await database.category.findUnique({ where: { id: req.params.id } });
    if (!current) return notFound(req, res);
    const data = input.data;
    const updated = await database.category.update({
      where: { id: current.id },
      data: {
        ...data,
        slug: data.name === current.name ? current.slug : await uniqueSlug("category", data.name, current.id),
        active: data.active === "true"
      }
    });
    await logActivity(req, "CATEGORY_UPDATED", updated.id);
    req.session.flash = { type: "success", message: `${updated.name} updated.` };
    res.redirect("/owner/categories");
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/categories/:id/delete", async (req, res, next) => {
  try {
    const category = await database.category.findUnique({ where: { id: req.params.id } });
    if (!category) return notFound(req, res);
    const count = await database.service.count({ where: { categoryId: req.params.id } });
    if (count) {
      req.session.flash = { type: "error", message: req.t("categoryInUse") };
      return res.redirect("/owner/categories");
    }
    const deleted = await database.category.delete({ where: { id: req.params.id } });
    await logActivity(req, "CATEGORY_DELETED", deleted.id);
    res.redirect("/owner/categories");
  } catch (error) {
    next(error);
  }
});

ownerRouter.get("/orders", async (req, res, next) => {
  try {
    const orders = await database.order.findMany({
      include: { user: true, service: true, payment: true },
      orderBy: { createdAt: "desc" },
      take: 100
    });
    res.render("owner/orders", { orders });
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/orders/:id", async (req, res, next) => {
  try {
    const order = await database.order.findUnique({ where: { id: req.params.id }, include: { service: true } });
    if (!order) return notFound(req, res);
    const decision = z.enum(["OFFER", "COMPLETE", "CANCEL"]).safeParse(req.body.decision);
    if (!decision.success) return renderInvalid(req, res, "/owner/orders");
    const adminNotes = String(req.body.adminNotes || "").trim().slice(0, 4000);

    if (decision.data === "OFFER") {
      if (["COMPLETED", "CANCELLED", "REFUNDED"].includes(order.status) || order.paymentStatus === "PAID") {
        req.session.flash = { type: "error", message: "A new offer cannot be sent for a closed or paid order." };
        return res.redirect("/owner/orders");
      }
      const amount = z.coerce.number().positive().max(1000000).safeParse(req.body.amount);
      if (!amount.success) return renderInvalid(req, res, "/owner/orders");
      await database.order.update({
        where: { id: order.id },
        data: {
          amount: amount.data,
          status: "AWAITING_CLIENT",
          paymentStatus: "UNPAID",
          ownerAcceptedAt: new Date(),
          clientAcceptedAt: null,
          adminNotes
        }
      });
      await logActivity(req, "ORDER_OFFER_SENT", order.id);
      req.session.flash = { type: "success", message: "Offer sent. The client must accept before payment is available." };
    } else if (decision.data === "COMPLETE") {
      if (!order.clientAcceptedAt || order.status !== "PROCESSING") {
        req.session.flash = { type: "error", message: "The client must accept the offer before the order can be completed." };
        return res.redirect("/owner/orders");
      }
      await database.order.update({
        where: { id: order.id },
        data: { status: "COMPLETED", completedAt: new Date(), adminNotes }
      });
      await logActivity(req, "ORDER_UPDATED", order.id);
      req.session.flash = { type: "success", message: "Order completed." };
    } else {
      if (order.paymentStatus === "PAID") {
        req.session.flash = { type: "error", message: "Refund the payment before cancelling a paid order." };
        return res.redirect("/owner/orders");
      }
      await database.order.update({
        where: { id: order.id },
        data: { status: "CANCELLED", adminNotes }
      });
      await logActivity(req, "ORDER_UPDATED", order.id);
      req.session.flash = { type: "success", message: "Order cancelled." };
    }
    res.redirect("/owner/orders");
  } catch (error) {
    next(error);
  }
});

ownerRouter.get("/users", async (req, res, next) => {
  try {
    const page = positiveInt(req.query.page, 1, 100000);
    const search = String(req.query.q || "").trim().slice(0, 100);
    const where = {
      role: "USER",
      ...(search ? {
        OR: [
          { name: { contains: search } },
          { email: { contains: search } }
        ]
      } : {})
    };
    const pageSize = 25;
    const [users, total, totalClients, activeClients, clientsWithRequests] = await Promise.all([
      database.user.findMany({
        where,
        select: {
          id: true, name: true, email: true, role: true, active: true,
          createdAt: true, lastLoginAt: true, _count: { select: { orders: true } }
        },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize
      }),
      database.user.count({ where }),
      database.user.count({ where: { role: "USER" } }),
      database.user.count({ where: { role: "USER", active: true } }),
      database.user.count({ where: { role: "USER", orders: { some: {} } } })
    ]);
    res.render("owner/users", {
      users, search, page, total,
      pageCount: Math.max(1, Math.ceil(total / pageSize)),
      totalClients, activeClients, clientsWithRequests
    });
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/users/:id/status", async (req, res, next) => {
  try {
    if (req.params.id === req.user.id) {
      req.session.flash = { type: "error", message: "You cannot disable your own account." };
      return res.redirect("/owner/users");
    }
    const parsedActive = z.enum(["true", "false"]).safeParse(req.body.active);
    if (!parsedActive.success) return renderInvalid(req, res, "/owner/users");
    const target = await database.user.findUnique({ where: { id: req.params.id } });
    if (!target) return notFound(req, res);
    if (target.role === "OWNER") {
      return res.status(403).render("errors/error", {
        status: 403,
        title: req.t("forbiddenTitle"),
        message: req.t("noPermission")
      });
    }
    const active = parsedActive.data === "true";
    const user = await database.user.update({ where: { id: req.params.id }, data: { active } });
    await logActivity(req, "USER_STATUS_CHANGED", user.id);
    res.redirect("/owner/users");
  } catch (error) {
    next(error);
  }
});

ownerRouter.get("/settings", async (req, res, next) => {
  try {
    const rows = await database.siteSetting.findMany();
    res.render("owner/settings", {
      settings: Object.fromEntries(rows.map(({ key, value }) => [key, value]))
    });
  } catch (error) {
    next(error);
  }
});

ownerRouter.post("/settings", async (req, res, next) => {
  try {
    const values = {
      agencyName: String(req.body.agencyName || "").trim().slice(0, 100),
      contactEmail: String(req.body.contactEmail || "").trim().slice(0, 254),
      website: String(req.body.website || "").trim().slice(0, 300),
      whatsappNumber: String(req.body.whatsappNumber || "").trim().slice(0, 30),
      discordUrl: String(req.body.discordUrl || "").trim().slice(0, 300),
      maintenanceMode: req.body.maintenanceMode === "true" ? "true" : "false"
    };
    const validWebsite = !values.website
      || (z.string().url().safeParse(values.website).success && /^https?:\/\//i.test(values.website));
    const validWhatsapp = !values.whatsappNumber || /^\+?[0-9().\s-]{7,30}$/.test(values.whatsappNumber);
    const discordAddress = values.discordUrl ? safeUrl(values.discordUrl) : null;
    const validDiscord = !values.discordUrl || Boolean(discordAddress
      && ["discord.gg", "discord.com", "www.discord.com"].includes(discordAddress.hostname));
    if (!values.agencyName || !validWebsite
      || !validWhatsapp || !validDiscord
      || (values.contactEmail && !z.string().email().safeParse(values.contactEmail).success)) {
      return renderInvalid(req, res, "/owner/settings");
    }
    await Promise.all(Object.entries(values).map(([key, value]) =>
      database.siteSetting.upsert({ where: { key }, create: { key, value }, update: { value } })
    ));
    clearMaintenanceCache();
    await logActivity(req, "SETTINGS_UPDATED", "site");
    req.session.flash = { type: "success", message: req.t("settingsSaved") };
    res.redirect("/owner/settings");
  } catch (error) {
    next(error);
  }
});

ownerRouter.get("/logs", async (req, res, next) => {
  try {
    const logs = await database.activityLog.findMany({
      include: { user: { select: { name: true, email: true } } },
      orderBy: { createdAt: "desc" },
      take: 200
    });
    res.render("owner/logs", { logs });
  } catch (error) {
    next(error);
  }
});

function cleanService(data) {
  return {
    name: data.name,
    nameAr: data.nameAr || null,
    shortDescription: data.shortDescription,
    shortDescriptionAr: data.shortDescriptionAr || null,
    description: data.description,
    descriptionAr: data.descriptionAr || null,
    categoryId: data.categoryId,
    price: data.price,
    pricingModel: data.pricingModel,
    currency: data.currency,
    icon: data.icon,
    iconImage: data.iconImage || null,
    image: data.image || null,
    features: parseLines(data.features),
    featuresAr: data.featuresAr || null,
    requirements: parseLines(data.requirements),
    requirementsAr: data.requirementsAr || null,
    faqs: parseFaqs(data.faqs),
    faqsAr: data.faqsAr || null,
    deliveryTime: data.deliveryTime,
    deliveryTimeAr: data.deliveryTimeAr || null,
    displayOrder: data.displayOrder,
    featured: data.featured === "true",
    active: data.active === "true"
  };
}

function parseLines(value) {
  return String(value || "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean).slice(0, 30);
}

function parseFaqs(value) {
  return String(value || "").split(/\r?\n/).map((line) => {
    const separator = line.indexOf("|");
    if (separator < 0) return null;
    return {
      question: line.slice(0, separator).trim().slice(0, 200),
      answer: line.slice(separator + 1).trim().slice(0, 1000)
    };
  }).filter((item) => item && item.question && item.answer).slice(0, 20);
}

function positiveInt(value, fallback, maximum) {
  const parsed = Number.parseInt(value, 10);
  return Number.isInteger(parsed) && parsed > 0 ? Math.min(parsed, maximum) : fallback;
}

function currencyTotals(groups) {
  return groups.length
    ? groups.map(({ currency, _sum }) => `${currency} ${Number(_sum.amount || 0).toFixed(2)}`).join(" · ")
    : "USD 0.00";
}

async function uniqueSlug(model, name, excludeId) {
  const base = toSlug(name);
  let slug = base || `item-${Date.now()}`;
  let suffix = 2;
  while (true) {
    const existing = await database[model].findUnique({ where: { slug } });
    if (!existing || existing.id === excludeId) return slug;
    slug = `${base}-${suffix++}`;
  }
}

async function logActivity(req, action, target) {
  await database.activityLog.create({
    data: {
      userId: req.user.id,
      action,
      target: String(target || "").slice(0, 200),
      ipAddress: req.ip,
      userAgent: String(req.get("user-agent") || "").slice(0, 500)
    }
  });
}

function safeUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" ? url : null;
  } catch {
    return null;
  }
}

function renderInvalid(req, res, target) {
  req.session.flash = { type: "error", message: "Please check the submitted fields and try again." };
  res.redirect(target);
}

function notFound(req, res) {
  return res.status(404).render("errors/error", {
    status: 404, title: req.t("notFoundTitle"), message: req.t("notFoundMessage")
  });
}

module.exports = { ownerRouter };
