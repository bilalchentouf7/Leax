const crypto = require("node:crypto");
const express = require("express");
const { rateLimit } = require("express-rate-limit");
const { database } = require("../utils/database");
const { requireAuth } = require("../middleware/auth");
const { paypalEnabled, paypalApi, amountMatches } = require("../utils/paypal");
const { logger } = require("../utils/logger");

const paymentsRouter = express.Router();
const checkoutLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  standardHeaders: "draft-7",
  legacyHeaders: false
});
paymentsRouter.use(requireAuth);
paymentsRouter.use(checkoutLimiter);

paymentsRouter.post("/paypal/:orderId/create", async (req, res, next) => {
  try {
    if (!paypalEnabled) {
      req.session.flash = { type: "error", message: "Online payment is not configured yet. Your request remains unpaid." };
      return res.redirect("/dashboard");
    }
    const order = await database.order.findFirst({
      where: { id: req.params.orderId, userId: req.user.id },
      include: { service: true }
    });
    if (!order) return notFound(req, res);
    if (!canStartPayment(order, order.service)) {
      req.session.flash = {
        type: "error",
        message: order.service.pricingModel === "MONTHLY"
          ? "Monthly service billing must be arranged directly with the team."
          : "Payment is available only after the owner makes an offer and you accept it."
      };
      return res.redirect("/dashboard");
    }

    const baseUrl = (process.env.BASE_URL || `${req.protocol}://${req.get("host")}`).replace(/\/+$/, "");
    const externalOrder = await paypalApi("/v2/checkout/orders", {
      method: "POST",
      requestId: crypto.randomUUID(),
      body: {
        intent: "CAPTURE",
        purchase_units: [{
          reference_id: order.id,
          custom_id: order.id,
          invoice_id: order.id,
          amount: {
            currency_code: order.currency.toUpperCase(),
            value: Number(order.amount).toFixed(2)
          }
        }],
        application_context: {
          brand_name: "LeaxSys",
          user_action: "PAY_NOW",
          return_url: `${baseUrl}/payments/paypal/return?order=${encodeURIComponent(order.id)}`,
          cancel_url: `${baseUrl}/payments/paypal/cancel?order=${encodeURIComponent(order.id)}`
        }
      }
    });
    const approvalLink = externalOrder.links?.find((link) => link.rel === "approve")?.href;
    const paypalOrderId = externalOrder.id;
    if (!paypalOrderId || !approvalLink || !isTrustedApprovalUrl(approvalLink)) {
      throw new Error("PayPal returned an invalid checkout approval response.");
    }
    await database.order.update({
      where: { id: order.id },
      data: { paypalOrderId, paymentStatus: "PENDING" }
    });
    await database.payment.upsert({
      where: { orderId: order.id },
      create: {
        orderId: order.id, provider: "PAYPAL", amount: order.amount,
        currency: order.currency, status: "PENDING"
      },
      update: { amount: order.amount, currency: order.currency, status: "PENDING" }
    });
    await database.activityLog.create({
      data: {
        userId: req.user.id, action: "PAYMENT_STARTED", target: order.id,
        ipAddress: req.ip, userAgent: String(req.get("user-agent") || "").slice(0, 500)
      }
    });
    res.redirect(approvalLink);
  } catch (error) {
    logger.error({ err: error, orderId: req.params.orderId }, "PayPal checkout creation failed");
    next(error);
  }
});

paymentsRouter.get("/paypal/return", async (req, res, next) => {
  try {
    if (!paypalEnabled) return res.redirect("/dashboard");
    const orderId = String(req.query.order || "");
    const paypalOrderId = String(req.query.token || "");
    const order = await database.order.findFirst({
      where: { id: orderId, userId: req.user.id },
      include: { service: true }
    });
    if (!order) return notFound(req, res);
    if (order.paymentStatus === "PAID") return res.redirect("/dashboard");
    if (!canStartPayment(order, order.service)) {
      req.session.flash = { type: "error", message: "The order is no longer approved for payment." };
      return res.redirect("/dashboard");
    }
    if (!paypalOrderId || order.paypalOrderId !== paypalOrderId) {
      return res.status(400).render("errors/error", {
        status: 400, title: "Payment could not be verified",
        message: "The payment reference does not match this order."
      });
    }
    const captureResponse = await paypalApi(`/v2/checkout/orders/${encodeURIComponent(paypalOrderId)}/capture`, {
      method: "POST",
      requestId: `capture-${paypalOrderId}`
    });
    const purchase = captureResponse.purchase_units?.find((unit) =>
      unit.reference_id === order.id && unit.custom_id === order.id
    );
    const capture = purchase?.payments?.captures?.find((item) => item.status === "COMPLETED");
    if (captureResponse.status !== "COMPLETED" || !capture?.id
      || !amountMatches(capture.amount, order.amount, order.currency)) {
      await markPaymentFailed(order, capture);
      await database.activityLog.create({
        data: {
          userId: req.user.id, action: "PAYMENT_VERIFICATION_FAILED", target: order.id,
          ipAddress: req.ip, userAgent: String(req.get("user-agent") || "").slice(0, 500)
        }
      });
      req.session.flash = { type: "error", message: "Payment was not confirmed. Your order remains unpaid." };
      return res.redirect("/dashboard");
    }

    await Promise.all([
      database.order.update({
        where: { id: order.id },
        data: { paymentStatus: "PAID", status: order.status === "PENDING" ? "PROCESSING" : order.status }
      }),
      database.payment.upsert({
        where: { orderId: order.id },
        create: {
          orderId: order.id, provider: "PAYPAL", providerPaymentId: capture.id,
          amount: order.amount, currency: order.currency, status: "PAID"
        },
        update: {
          providerPaymentId: capture.id,
          amount: order.amount, currency: order.currency, status: "PAID"
        }
      }),
      database.activityLog.create({
        data: {
          userId: req.user.id, action: "PAYMENT_COMPLETED", target: order.id,
          ipAddress: req.ip, userAgent: String(req.get("user-agent") || "").slice(0, 500)
        }
      })
    ]);
    req.session.flash = { type: "success", message: "Payment confirmed. Your order is processing." };
    res.redirect("/dashboard");
  } catch (error) {
    logger.error({ err: error }, "PayPal capture verification failed");
    next(error);
  }
});

paymentsRouter.get("/paypal/cancel", async (req, res, next) => {
  try {
    const order = await database.order.findFirst({
      where: { id: String(req.query.order || ""), userId: req.user.id }
    });
    if (!order) return notFound(req, res);
    if (order.paymentStatus !== "PAID") {
      await markPaymentFailed(order);
      req.session.flash = { type: "error", message: "Checkout was cancelled. Your order is still unpaid." };
    }
    res.redirect("/dashboard");
  } catch (error) {
    next(error);
  }
});

async function markPaymentFailed(order, capture) {
  const operations = [
    () => database.order.updateMany({
      where: { id: order.id, paymentStatus: { not: "PAID" } },
      data: { paymentStatus: "FAILED" }
    }),
    () => database.payment.updateMany({
      where: { orderId: order.id, status: { not: "PAID" } },
      data: { status: "FAILED" }
    })
  ];
  if (capture?.id && capture.amount?.value && capture.amount?.currency_code) {
    operations.push(() => database.payment.upsert({
      where: { orderId: order.id },
      create: {
        orderId: order.id,
        provider: "PAYPAL",
        providerPaymentId: capture.id,
        amount: capture.amount.value,
        currency: capture.amount.currency_code,
        status: "FAILED"
      },
      update: {
        providerPaymentId: capture.id,
        amount: capture.amount.value,
        currency: capture.amount.currency_code,
        status: "FAILED"
      }
    }));
  }
  await Promise.all(operations.map((operation) => operation()));
}

function isTrustedApprovalUrl(value) {
  try {
    const parsed = new URL(value);
    return parsed.protocol === "https:"
      && ["www.paypal.com", "www.sandbox.paypal.com"].includes(parsed.hostname);
  } catch {
    return false;
  }
}

function notFound(req, res) {
  return res.status(404).render("errors/error", {
    status: 404, title: req.t("notFoundTitle"), message: req.t("notFoundMessage")
  });
}

function canStartPayment(order, service) {
  return Boolean(order && service
    && ["FIXED", "QUOTE"].includes(service.pricingModel)
    && order.status === "PROCESSING"
    && order.ownerAcceptedAt
    && order.clientAcceptedAt
    && order.paymentStatus !== "PAID"
    && Number.isFinite(Number(order.amount))
    && Number(order.amount) > 0);
}

module.exports = { paymentsRouter, isTrustedApprovalUrl, canStartPayment };
